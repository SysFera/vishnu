/**
 * Sample script to fill the tables for the test
 */
insert into vishnu("updatefreq", "formatiduser", "formatidjob", "formatidtransfer", "formatidmachine", "usercpt", "jobcpt", "transfercpt", "machinecpt") values ('100', '$toto', '$titi', '$tutu', '$tata', '0', '0', '0', '0');
insert into users("userid", "password", "firstname", "lastname", "email", "privilege", "passwordstate", "numvishnuid") values('ben', '123', 'ben', 'ben', 'toto', 'a', 1, 1);
insert into machine("machineid","name","site","totaldiskspace", "totalmemory", "network", "numvishnuid") values('machine0', 'graal', 'ens', '3500', '456', 'parisToBerlin', '1');
insert into machine("machineid","name","site","totaldiskspace", "totalmemory", "network", "numvishnuid") values('machine1', 'nutella', 'france', '3530', '436', 'parisToBerlin2', '1');
insert into machine("machineid","name","site","totaldiskspace", "totalmemory", "network", "numvishnuid") values('machine2', 'lapin', 'bordeaux', '530', '46', 'parisToBerlin3', '1');
insert into machine("machineid","name","site","totaldiskspace", "totalmemory", "network", "numvishnuid") values('machine3', 'toto', 'lyon', '353', '36', 'parisToBerlin4', '1');
insert into options("optionid", "description", "defaultvalue") values('Chocolat', 'The best thing in the world', 'Nutella');
insert into options("optionid", "description", "defaultvalue") values('Crepe', 'Better than drugs', 'Chantilly');
insert into options("optionid", "description", "defaultvalue") values('Glace', 'Divine food', 'Menthe-chocolat');
insert into optionvalue("val","numoptionid", "numuserid") values('Fondant au chocolat', '1', '1');
insert into optionvalue("val","numoptionid", "numuserid") values('Coulis de nutella', '2', '1');
insert into optionvalue("val","numoptionid", "numuserid") values('Poire belle Helene', '3', '1');

