/**
 * Script to create all the tables of the mock up
 */

/**
 * UMS TABLES
 **/

/**
 * Basic table containing the VISHNU configuration data
 **/
create table vishnu (
numvishnuid serial primary key,
updatefreq integer,
formatiduser varchar(100),
formatidjob varchar(100),
formatidtransfer varchar(100),
formatidmachine varchar(100),
usercpt integer,
jobcpt integer,
transfercpt integer,
machinecpt integer
);

/**
 * table containing the user and its attributes
 */
create table users (
numuserid serial primary key,
userid varchar(100) not null,
password varchar(200),
firstname varchar(100),
lastname varchar(100),
email varchar(100),
privilege varchar(1),
passwordstate integer,
numvishnuid integer references vishnu(numvishnuid)
);

/**
 * table containing the machine 
 */
create table machine (
nummachineid serial primary key,
machineid varchar(100),
name varchar(100),
site varchar(100),
totaldiskspace integer,
totalmemory integer,
network varchar(100),
numvishnuid integer references vishnu(numvishnuid)
);

/**
 * table containing the account of the user information
 */
create table account (
numaccount serial primary key,
aclogin varchar(100),
sshpathkey varchar(100),
homedirectory varchar(100),
numuserid integer references users(numuserid),
nummachineid integer references machine(nummachineid)
);

/**
 * table containing the sessions and their attributes
 */
create table sessions (
numsessionid serial primary key,
sessionid serial,
lastconnect integer,
creation integer,
sessionkey varchar(100),
states varchar(30),
closepolicy varchar(50),
timeoutdate integer,
numuserid integer references users(numuserid)
);

/**
 * table containing all the commands entered in vishnu
 */
create table commands (
numcommandid serial primary key,
commandid integer,
starttime integer,
endtime integer,
cmddescription varchar(200),
cmdtype varchar(100),
nummachineid integer references machine(nummachineid),
numsessionid integer references sessions(numsessionid)
);

/**
 * table containing the option of the user
 */
create table options (
numoptionid serial primary key,
optionid varchar(20),
description varchar(200),
defaultvalue varchar(100)
);

/**
 * table containing the values of the tables
 */
create table optionvalue (
optionvalueid serial primary key,
val varchar(100),
numoptionid integer references options(numoptionid),
numuserid integer references users(numuserid)
);


/**
 * tms tables
 **/

create table job (
numjobid serial primary key,
jobid varchar(100),
jobstate varchar(100),
jobpath varchar(100),
joboutputpath varchar(100),
joberrorpath varchar(100),
submitdir varchar(100),
numcommandid integer references commands(numcommandid)
);

create table file (
numfileid serial primary key,
namefile varchar(100),
content varchar(1000),
numcommandid integer references commands(numcommandid)
);

 GRANT ALL ON TABLE file TO "admin";
 GRANT ALL ON TABLE job TO "admin";
 GRANT ALL ON TABLE optionvalue TO "admin";
 GRANT ALL ON TABLE options TO "admin";
 GRANT ALL ON TABLE account TO "admin";
 GRANT ALL ON TABLE commands TO "admin";
 GRANT ALL ON TABLE sessions TO "admin";
 GRANT ALL ON TABLE machine TO "admin";
 GRANT ALL ON TABLE users TO "admin";
 GRANT ALL ON TABLE vishnu TO "admin";


GRANT ALL ON SEQUENCE file_numfileid_seq TO "admin";
 GRANT ALL ON SEQUENCE job_numjobid_seq TO "admin";
 GRANT ALL ON SEQUENCE optionvalue_optionvalueid_seq TO "admin";
 GRANT ALL ON SEQUENCE options_numoptionid_seq TO "admin";
 GRANT ALL ON SEQUENCE account_numaccount_seq TO "admin";
 GRANT ALL ON SEQUENCE commands_numcommandid_seq TO "admin";
 GRANT ALL ON SEQUENCE sessions_numsessionid_seq TO "admin";
 GRANT ALL ON SEQUENCE sessions_sessionid_seq TO "admin";
 GRANT ALL ON SEQUENCE machine_nummachineid_seq TO "admin";
 GRANT ALL ON SEQUENCE users_numuserid_seq TO "admin";
 GRANT ALL ON SEQUENCE vishnu_numvishnuid_seq TO "admin";

