#!/bin/sh

createdb mockup
createuser -S --pwprompt
