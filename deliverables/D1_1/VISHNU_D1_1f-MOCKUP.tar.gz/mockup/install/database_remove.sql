/**
 * Script to remove all the tables of the mock up
 */

/**
 * UMS TABLES
 */
drop table "file";
drop table "job";
drop table "optionvalue";
drop table "options";
drop table "account";
drop table "commands";
drop table "sessions";
drop table "machine";
drop table "users";
drop table "vishnu";
