package com.sysfera.vishnu.api.mockup;

import java.sql.*;

public class Database {
	
	// Singleton initialization
	public static Database getInstance() {
		if (null == m_instance) {
			synchronized(Database.class) {
				if (null == m_instance)
					m_instance = new Database();
			}
		}
		return m_instance;
	}
	
	// Singleton instance
	private volatile static Database m_instance = null;
	
	// Database login/password
	private static String DB_NAME 		= "mockup";
	private static String DB_LOGIN 		= "admin";
	private static String DB_PASSWORD 	= "admin";
	
	// Database object
	private Connection m_conn = null;
	
	protected Database() {
		// Driver initialization
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Could not initialize PostgreSQL driver", e);
		}
		// Database connection
		try {
			m_conn = DriverManager.getConnection("jdbc:postgresql:" + DB_NAME, DB_LOGIN, DB_PASSWORD);
		} catch (SQLException e) {
			throw new RuntimeException("Could not connect to database '" + DB_NAME +"'", e);
		}
	}
	
	public Statement createStatement() {
		try {
			return m_conn.createStatement();
		} catch (SQLException e) {
			throw new RuntimeException("Problem with database connection", e);
		}
	}
	
	
}
