
package com.sysfera.vishnu.api.tms;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.sysfera.vishnu.api.tms package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.sysfera.vishnu.api.tms
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SubmitJobRequest }
     * 
     */
    public SubmitJobRequest createSubmitJobRequest() {
        return new SubmitJobRequest();
    }

    /**
     * Create an instance of {@link TMSUNKNOWNQUEUEFault }
     * 
     */
    public TMSUNKNOWNQUEUEFault createTMSUNKNOWNQUEUEFault() {
        return new TMSUNKNOWNQUEUEFault();
    }

    /**
     * Create an instance of {@link ListQueuesRequest }
     * 
     */
    public ListQueuesRequest createListQueuesRequest() {
        return new ListQueuesRequest();
    }

    /**
     * Create an instance of {@link ListQueuesResponse }
     * 
     */
    public ListQueuesResponse createListQueuesResponse() {
        return new ListQueuesResponse();
    }

    /**
     * Create an instance of {@link GetJobProgressResponse }
     * 
     */
    public GetJobProgressResponse createGetJobProgressResponse() {
        return new GetJobProgressResponse();
    }

    /**
     * Create an instance of {@link GetJobInfoResponse }
     * 
     */
    public GetJobInfoResponse createGetJobInfoResponse() {
        return new GetJobInfoResponse();
    }

    /**
     * Create an instance of {@link GetAllJobsOutPutResponse.Data }
     * 
     */
    public GetAllJobsOutPutResponse.Data createGetAllJobsOutPutResponseData() {
        return new GetAllJobsOutPutResponse.Data();
    }

    /**
     * Create an instance of {@link TMSPERMISSIONDENIEDFault }
     * 
     */
    public TMSPERMISSIONDENIEDFault createTMSPERMISSIONDENIEDFault() {
        return new TMSPERMISSIONDENIEDFault();
    }

    /**
     * Create an instance of {@link GetAllJobsOutPutRequest }
     * 
     */
    public GetAllJobsOutPutRequest createGetAllJobsOutPutRequest() {
        return new GetAllJobsOutPutRequest();
    }

    /**
     * Create an instance of {@link ListJobsResponse }
     * 
     */
    public ListJobsResponse createListJobsResponse() {
        return new ListJobsResponse();
    }

    /**
     * Create an instance of {@link GetAllJobsOutPutResponse }
     * 
     */
    public GetAllJobsOutPutResponse createGetAllJobsOutPutResponse() {
        return new GetAllJobsOutPutResponse();
    }

    /**
     * Create an instance of {@link TMSUNKNOWNBATCHSCHEDULERTYPEFault }
     * 
     */
    public TMSUNKNOWNBATCHSCHEDULERTYPEFault createTMSUNKNOWNBATCHSCHEDULERTYPEFault() {
        return new TMSUNKNOWNBATCHSCHEDULERTYPEFault();
    }

    /**
     * Create an instance of {@link ListQueuesResponse.Data.Queue }
     * 
     */
    public ListQueuesResponse.Data.Queue createListQueuesResponseDataQueue() {
        return new ListQueuesResponse.Data.Queue();
    }

    /**
     * Create an instance of {@link TMSINVALIDRESPONSEFault }
     * 
     */
    public TMSINVALIDRESPONSEFault createTMSINVALIDRESPONSEFault() {
        return new TMSINVALIDRESPONSEFault();
    }

    /**
     * Create an instance of {@link TMSUNKNOWNTYPEOFERRORFault }
     * 
     */
    public TMSUNKNOWNTYPEOFERRORFault createTMSUNKNOWNTYPEOFERRORFault() {
        return new TMSUNKNOWNTYPEOFERRORFault();
    }

    /**
     * Create an instance of {@link CancelJobRequest }
     * 
     */
    public CancelJobRequest createCancelJobRequest() {
        return new CancelJobRequest();
    }

    /**
     * Create an instance of {@link ListJobsResponse.Data }
     * 
     */
    public ListJobsResponse.Data createListJobsResponseData() {
        return new ListJobsResponse.Data();
    }

    /**
     * Create an instance of {@link TMSSUBMITSERVICENOTAVAILABLEFault }
     * 
     */
    public TMSSUBMITSERVICENOTAVAILABLEFault createTMSSUBMITSERVICENOTAVAILABLEFault() {
        return new TMSSUBMITSERVICENOTAVAILABLEFault();
    }

    /**
     * Create an instance of {@link TMSINVALIDSESSIONKEYFault }
     * 
     */
    public TMSINVALIDSESSIONKEYFault createTMSINVALIDSESSIONKEYFault() {
        return new TMSINVALIDSESSIONKEYFault();
    }

    /**
     * Create an instance of {@link TMSSERVERNOTAVAILABLEFault }
     * 
     */
    public TMSSERVERNOTAVAILABLEFault createTMSSERVERNOTAVAILABLEFault() {
        return new TMSSERVERNOTAVAILABLEFault();
    }

    /**
     * Create an instance of {@link CancelJobResponse }
     * 
     */
    public CancelJobResponse createCancelJobResponse() {
        return new CancelJobResponse();
    }

    /**
     * Create an instance of {@link DBERRORFault }
     * 
     */
    public DBERRORFault createDBERRORFault() {
        return new DBERRORFault();
    }

    /**
     * Create an instance of {@link ListJobsRequest }
     * 
     */
    public ListJobsRequest createListJobsRequest() {
        return new ListJobsRequest();
    }

    /**
     * Create an instance of {@link VISHNUOKFault }
     * 
     */
    public VISHNUOKFault createVISHNUOKFault() {
        return new VISHNUOKFault();
    }

    /**
     * Create an instance of {@link TMSINVALIDPATHFault }
     * 
     */
    public TMSINVALIDPATHFault createTMSINVALIDPATHFault() {
        return new TMSINVALIDPATHFault();
    }

    /**
     * Create an instance of {@link TMSUNKNOWNMACHINEFault }
     * 
     */
    public TMSUNKNOWNMACHINEFault createTMSUNKNOWNMACHINEFault() {
        return new TMSUNKNOWNMACHINEFault();
    }

    /**
     * Create an instance of {@link GetJobProgressRequest }
     * 
     */
    public GetJobProgressRequest createGetJobProgressRequest() {
        return new GetJobProgressRequest();
    }

    /**
     * Create an instance of {@link ListJobsResponse.Data.Job }
     * 
     */
    public ListJobsResponse.Data.Job createListJobsResponseDataJob() {
        return new ListJobsResponse.Data.Job();
    }

    /**
     * Create an instance of {@link ListQueuesResponse.Data }
     * 
     */
    public ListQueuesResponse.Data createListQueuesResponseData() {
        return new ListQueuesResponse.Data();
    }

    /**
     * Create an instance of {@link GetJobOutPutRequest }
     * 
     */
    public GetJobOutPutRequest createGetJobOutPutRequest() {
        return new GetJobOutPutRequest();
    }

    /**
     * Create an instance of {@link GetAllJobsOutPutResponse.Data.Jobresult }
     * 
     */
    public GetAllJobsOutPutResponse.Data.Jobresult createGetAllJobsOutPutResponseDataJobresult() {
        return new GetAllJobsOutPutResponse.Data.Jobresult();
    }

    /**
     * Create an instance of {@link SubmitJobResponse }
     * 
     */
    public SubmitJobResponse createSubmitJobResponse() {
        return new SubmitJobResponse();
    }

    /**
     * Create an instance of {@link GetJobInfoRequest }
     * 
     */
    public GetJobInfoRequest createGetJobInfoRequest() {
        return new GetJobInfoRequest();
    }

    /**
     * Create an instance of {@link TMSBATCHSCHEDULERERRORFault }
     * 
     */
    public TMSBATCHSCHEDULERERRORFault createTMSBATCHSCHEDULERERRORFault() {
        return new TMSBATCHSCHEDULERERRORFault();
    }

    /**
     * Create an instance of {@link TMSINVALIDREQUESTFault }
     * 
     */
    public TMSINVALIDREQUESTFault createTMSINVALIDREQUESTFault() {
        return new TMSINVALIDREQUESTFault();
    }

    /**
     * Create an instance of {@link GetJobOutPutResponse }
     * 
     */
    public GetJobOutPutResponse createGetJobOutPutResponse() {
        return new GetJobOutPutResponse();
    }

}
