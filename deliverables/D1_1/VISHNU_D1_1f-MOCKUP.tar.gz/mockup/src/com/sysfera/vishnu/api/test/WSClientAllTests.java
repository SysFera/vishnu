package com.sysfera.vishnu.api.test;

import java.net.MalformedURLException;
import java.net.URL;

import com.sysfera.vishnu.api.tms.VishnuTMSPortType;
import com.sysfera.vishnu.api.tms.VishnuTMSService;
import com.sysfera.vishnu.api.ums.VishnuUMSPortType;
import com.sysfera.vishnu.api.ums.VishnuUMSService;

public class WSClientAllTests {
	
	public static void main(String args[]) throws Exception {
		
		System.out.println("INIT TESTS");
		// Check command-line arguments
		if (args.length < 1) {
			System.out.println("Usage: WSClientAllTests <host>");
			System.exit(1);
		}
		// Initialize web service interface
		VishnuTMSPortType TMSport = getTMSPort("http://" + args[0] + ":8080/WSAPI/VishnuTMS?wsdl");
		VishnuUMSPortType UMSport = getUMSPort("http://" + args[0] + ":8080/WSAPI/VishnuUMS?wsdl");
		
		System.out.println("START TESTS");
		int nbTests = 0;
		int nbErrors = 0;
		WSClientTest1 test1 = new WSClientTest1(UMSport); nbTests++;
		nbErrors += test1.run();
		WSClientTest2 test2 = new WSClientTest2(UMSport,TMSport); nbTests++;
		nbErrors += test2.run();
		
		System.out.println("DONE ALL TESTS (" + (nbTests-nbErrors) + " PASSED / " + nbErrors + " FAILED)");
	}
	
	private static VishnuTMSPortType getTMSPort(String endpointURI) throws MalformedURLException   {

		URL wsdlURL = new URL(endpointURI);
		VishnuTMSService service = new VishnuTMSService(wsdlURL);
		return service.getVishnuTMSPort();
	}
	
	private static VishnuUMSPortType getUMSPort(String endpointURI) throws MalformedURLException   {

		URL wsdlURL = new URL(endpointURI);
		VishnuUMSService service = new VishnuUMSService(wsdlURL);
		return service.getVishnuUMSPort();
	}

}
