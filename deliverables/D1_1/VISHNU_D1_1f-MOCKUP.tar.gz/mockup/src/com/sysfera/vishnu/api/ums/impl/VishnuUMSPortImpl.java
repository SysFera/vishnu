package com.sysfera.vishnu.api.ums.impl;

import java.sql.*;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.jws.WebService;

import com.sysfera.vishnu.api.mockup.Database;
import com.sysfera.vishnu.api.ums.AddLocalAccountRequest;
import com.sysfera.vishnu.api.ums.AddLocalAccountResponse;
import com.sysfera.vishnu.api.ums.COMMANDRUNNINGMessage;
import com.sysfera.vishnu.api.ums.ChangePasswordRequest;
import com.sysfera.vishnu.api.ums.ChangePasswordResponse;
import com.sysfera.vishnu.api.ums.CloseRequest;
import com.sysfera.vishnu.api.ums.CloseResponse;
import com.sysfera.vishnu.api.ums.ConfigureOptionRequest;
import com.sysfera.vishnu.api.ums.ConfigureOptionResponse;
import com.sysfera.vishnu.api.ums.ConnectRequest;
import com.sysfera.vishnu.api.ums.ConnectResponse;
import com.sysfera.vishnu.api.ums.DBERRORMessage;
import com.sysfera.vishnu.api.ums.DeleteLocalAccountRequest;
import com.sysfera.vishnu.api.ums.DeleteLocalAccountResponse;
import com.sysfera.vishnu.api.ums.INCORRECTDATEOPTIONMessage;
import com.sysfera.vishnu.api.ums.INCORRECTTIMEOUTMessage;
import com.sysfera.vishnu.api.ums.LOCALACCOUNTEXISTMessage;
import com.sysfera.vishnu.api.ums.ListHistoryCmdRequest;
import com.sysfera.vishnu.api.ums.ListHistoryCmdResponse;
import com.sysfera.vishnu.api.ums.ListLocalAccountRequest;
import com.sysfera.vishnu.api.ums.ListLocalAccountResponse;
import com.sysfera.vishnu.api.ums.ListMachineRequest;
import com.sysfera.vishnu.api.ums.ListMachineResponse;
import com.sysfera.vishnu.api.ums.ListOptionsRequest;
import com.sysfera.vishnu.api.ums.ListOptionsResponse;
import com.sysfera.vishnu.api.ums.ListSessionsRequest;
import com.sysfera.vishnu.api.ums.ListSessionsResponse;
import com.sysfera.vishnu.api.ums.MACHINEIDREQUIREDMessage;
import com.sysfera.vishnu.api.ums.NOADMINMessage;
import com.sysfera.vishnu.api.ums.NOTAUTHENTICATEDMessage;
import com.sysfera.vishnu.api.ums.SESSIONKEYEXPIREDMessage;
import com.sysfera.vishnu.api.ums.SESSIONKEYNOTFOUNDMessage;
import com.sysfera.vishnu.api.ums.SessionStateType;
import com.sysfera.vishnu.api.ums.UMSSERVERNOTAVAILABLEMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNCLOSUREMODEMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNLOCALACCOUNTMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNMACHINEMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNOPTIONMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNSESSIONOPTIONMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNUSERIDMessage;
import com.sysfera.vishnu.api.ums.USERIDREQUIREDMessage;
import com.sysfera.vishnu.api.ums.UpdateLocalAccountRequest;
import com.sysfera.vishnu.api.ums.UpdateLocalAccountResponse;
import com.sysfera.vishnu.api.ums.VISHNUOKMessage;
import com.sysfera.vishnu.api.ums.VishnuFinalizeRequest;
import com.sysfera.vishnu.api.ums.VishnuFinalizeResponse;
import com.sysfera.vishnu.api.ums.VishnuInitializeRequest;
import com.sysfera.vishnu.api.ums.VishnuInitializeResponse;
import com.sysfera.vishnu.api.ums.VishnuUMSPortType;
import com.sysfera.vishnu.api.ums.SessionCloseType;



@WebService(targetNamespace = "urn:ResourceProxy", name = "VishnuUMS", serviceName="VishnuUMSService")
    @Remote(VishnuUMSPortType.class)
    @Stateless
    public class VishnuUMSPortImpl implements VishnuUMSPortType {

	public UpdateLocalAccountResponse updateLocalAccount(UpdateLocalAccountRequest parameters) throws UNKNOWNMACHINEMessage, SESSIONKEYNOTFOUNDMessage, UNKNOWNLOCALACCOUNTMessage, DBERRORMessage,
													  SESSIONKEYEXPIREDMessage {
	    // Check if session key validx
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e); 
	    }
	    ////
	    // Get internal user id and machine id
	    ////
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String localUID;
	    String machineId;
	    String sqlText = "SELECT * FROM sessions where sessionkey = '" + parameters.getSessionKey()+"'";
	    // Get user num id
	    try {
		rs = sql.executeQuery(sqlText);
		rs.next();
		localUID = rs.getString(9);
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    String machine = "SELECT * FROM machine where machineid = '" + parameters.getMachineId() + "'";
	    // Get machine id
	    try {
		rs = sql.executeQuery(machine);
		if (!rs.next()){
		    throw new UNKNOWNMACHINEMessage("Invalid parameter");
		}
		machineId = rs.getString(1);
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    // Update
	    String condition = "WHERE numuserid = '"+localUID+"' AND nummachineid = '"+machineId+"'";

	    String accountinfo = "SELECT * FROM account "+condition;
	    String acLogin;
	    String path;
	    String home;
	    // Get account line value
	    try {
		rs = sql.executeQuery(accountinfo);
		rs.next();
		acLogin = rs.getString(2);
		path    = rs.getString(3);
		home    = rs.getString(4);
	    } catch (SQLException e) {
	    	throw new DBERRORMessage("query failed", e);
	    }

	    if (parameters.getAcLogin() != "")
		acLogin = parameters.getAcLogin();
	    if (parameters.getSshKeyPath() != "")
		path    = parameters.getSshKeyPath();
	    if (parameters.getHomeDirectory() != "")
		home    = parameters.getHomeDirectory();

	    String log = "UPDATE \"account\" set \"aclogin\"='"+acLogin+"', \"sshpathkey\"='"+path+"', \"homedirectory\"='"+home+"' "+condition;
	    try {
		sql.execute(log);
	    }catch(SQLException e){
		throw new DBERRORMessage("Query failed", e);
	    }
	    UpdateLocalAccountResponse rep = new UpdateLocalAccountResponse();
	    return rep;
	}

    
        public ListMachineResponse listMachine(ListMachineRequest parameters)
	    throws SESSIONKEYNOTFOUNDMessage, INCORRECTDATEOPTIONMessage, SESSIONKEYEXPIREDMessage, DBERRORMessage {
        	
	    // Check session key
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Get machines from db to build the list
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String sqlText = "SELECT * FROM machine";
	    ListMachineResponse rep = new ListMachineResponse();
	    ListMachineResponse.Data data = new ListMachineResponse.Data();
	    String machineID;
	    String name;
	    String site;

	    try {
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new DBERRORMessage("query failed");
		}
		do {
		    ListMachineResponse.Data.Machine machine = new ListMachineResponse.Data.Machine();
		    machineID = rs.getString(2);
		    name = rs.getString(3);
		    site = rs.getString(4);

		    machine.setMachineId(machineID);
		    machine.setName(name);
		    machine.setSite(site);
		    data.getMachine().add(machine);
		}while (rs.next());
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    rep.setData(data);
	    return rep;
	}

	public ListHistoryCmdResponse listHistoryCmd(
						     ListHistoryCmdRequest parameters) throws SESSIONKEYNOTFOUNDMessage, INCORRECTDATEOPTIONMessage, SESSIONKEYEXPIREDMessage, DBERRORMessage {
	    
	    // Check session key
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }

	    // Get machines from db to build the list
	    ListHistoryCmdResponse rep = new ListHistoryCmdResponse();
	    ListHistoryCmdResponse.Data data = new ListHistoryCmdResponse.Data();
	    String sessionID;
	    String commandID;
	    String machineID;
	    Long start;
	    Long end;
	    String description;

	    ListHistoryCmdResponse.Data.Command cmd = new ListHistoryCmdResponse.Data.Command();
	    machineID = "machine0";
	    sessionID = "1";
	    commandID = "connect";
	    start     = new Long(10000);
	    end       = new Long(10001);
	    description = "toto toto";

	    cmd.setMachineId(machineID);
	    cmd.setSessionId(sessionID);
	    cmd.setCommandId(commandID);
	    cmd.setCmdStartTime(start);
	    cmd.setCmdEndTime(end);
	    cmd.setCmdDescription(description);

	    data.getCommand().add(cmd);

	    cmd = new ListHistoryCmdResponse.Data.Command();
	    machineID = "machine0";
	    sessionID = "1";
	    commandID = "ls";
	    start     = new Long(10004);
	    end       = new Long(10005);
	    description = "-lrta";

	    cmd.setMachineId(machineID);
	    cmd.setSessionId(sessionID);
	    cmd.setCommandId(commandID);
	    cmd.setCmdStartTime(start);
	    cmd.setCmdEndTime(end);
	    cmd.setCmdDescription(description);
	    data.getCommand().add(cmd);

	    cmd = new ListHistoryCmdResponse.Data.Command();
	    machineID = "machine0";
	    sessionID = "1";
	    commandID = "disconnect";
	    start     = new Long(100007);
	    end       = new Long(10000006);
	    description = "";

	    cmd.setMachineId(machineID);
	    cmd.setSessionId(sessionID);
	    cmd.setCommandId(commandID);
	    cmd.setCmdStartTime(start);
	    cmd.setCmdEndTime(end);
	    cmd.setCmdDescription(description);
	    data.getCommand().add(cmd);
	
	    rep.setData(data);
	    return rep;
	}

	public ListOptionsResponse listOptions(ListOptionsRequest parameters)
	    throws SESSIONKEYNOTFOUNDMessage, NOADMINMessage,
		   INCORRECTDATEOPTIONMessage, SESSIONKEYEXPIREDMessage, UNKNOWNOPTIONMessage, DBERRORMessage {
	    // Check session key
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Get machines from db to build the list
	    Statement sql = db.createStatement();
	    ResultSet rs;

	   // Getting id of the user to get session from
	    String id = "0";
	    String req = "SELECT * FROM sessions WHERE sessionkey = '"+parameters.getSessionKey()+"'"; 
	    try{
		rs = sql.executeQuery(req);
		if (!rs.next()){
		    throw new SESSIONKEYNOTFOUNDMessage("session invalid");
		}
		id = rs.getString(9);
	    }catch(SQLException e){
		    throw new SESSIONKEYNOTFOUNDMessage("session invalid", e);
	    }


	    ListOptionsResponse rep = new ListOptionsResponse();
	    ListOptionsResponse.Data data = new ListOptionsResponse.Data();
	    String name;
	    String value;

	    String sqlText = "SELECT optionvalue.*, options.optionid from optionvalue, options WHERE numuserid = '"+ id +"' AND options.numoptionid = optionvalue.numoptionid";

	    try {
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new DBERRORMessage("query failed");
		}
		do {

		    ListOptionsResponse.Data.Optionvalue op = new ListOptionsResponse.Data.Optionvalue();
		    value = rs.getString(2);
		    name  = rs.getString(5);
		    op.setOptionName(name);
		    op.setValue(value);
		    data.getOptionvalue().add(op);
		}while (rs.next());
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    rep.setData(data);
	    return rep;
	}

	public ConfigureOptionResponse configureOption(
						       ConfigureOptionRequest parameters) throws SESSIONKEYNOTFOUNDMessage, SESSIONKEYEXPIREDMessage,
												 UNKNOWNOPTIONMessage, DBERRORMessage {
	    // Check if session key is valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		System.out.println ("Invalid session key");
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Get account from db to build list
	    Statement sql = db.createStatement();
	    ResultSet rs;

	   // Getting id of the user to get session from
	    String id = "0";
	    String req = "SELECT * FROM sessions WHERE sessionkey = '"+parameters.getSessionKey()+"'"; 
	    try{
		rs = sql.executeQuery(req);
		if (!rs.next())
		    throw new DBERRORMessage("db connection failed");
		id = rs.getString(9);
	    }catch(SQLException e){
		throw new DBERRORMessage("db connection failed", e);
	    }

	   // Getting id of the user to get session from
	    String idOp = "0";
	    String reqOp = "SELECT * FROM options WHERE optionid = '"+parameters.getOptionName()+"'"; 
	    try{
		rs = sql.executeQuery(reqOp);
		if (!rs.next())
		    throw new DBERRORMessage("db connection failed");
		idOp = rs.getString(1);
	    }catch(SQLException e){
		throw new DBERRORMessage("db connection failed", e);
	    }

	    String test = "SELECT * FROM optionvalue, options WHERE numuserid = '"+id+"' AND options.numoptionid = optionvalue.numoptionid AND options.optionid = '"+parameters.getOptionName()+"'";
	    String insert = new String();
	    try{
		rs = sql.executeQuery(test);
		if (!rs.next()){
		    if (rs.previous())
			insert = "UPDATE optionvalue SET \"val\" = '"+parameters.getValue()+"', \"numoptionid\"='"+idOp+"', \"numuserid\"='"+id+"' WHERE optionvalueid = '"+rs.getString(1)+"'";
		    else
			insert = "INSERT INTO optionvalue(\"val\", \"numoptionid\", \"numuserid\") values('"+parameters.getValue()+"', '"+idOp+"', '"+id+"')";
		}
		else
		    insert = "UPDATE optionvalue SET \"val\" = '"+parameters.getValue()+"', \"numoptionid\"='"+idOp+"', \"numuserid\"='"+id+"' WHERE optionvalueid = '"+rs.getString(1)+"'";
	    }catch(SQLException e){
		System.out.println("Req qui plante : "+test);
		System.out.println("Req qui plante2 : "+insert);
		throw new DBERRORMessage("Update failed", e);
	    }
	    
	    try{
		sql.execute(insert);
	    }catch(SQLException e){
		throw new DBERRORMessage("Update failed", e);
	    }

	    ConfigureOptionResponse rep = new ConfigureOptionResponse();
	    return rep;
	}

	public ListLocalAccountResponse listLocalAccount(
							 ListLocalAccountRequest parameters) throws SESSIONKEYNOTFOUNDMessage, INCORRECTDATEOPTIONMessage, SESSIONKEYEXPIREDMessage, DBERRORMessage {
	    // Check if session key is valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		System.out.println ("Invalid session key");
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Get account from db to build list
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String sqlText = "SELECT account.*, users.userid, machine.machineid FROM account, users, machine WHERE users.numuserid = account.numuserid AND machine.nummachineid = account.nummachineid";
	    ListLocalAccountResponse rep = new ListLocalAccountResponse();
	    ListLocalAccountResponse.Data data = new ListLocalAccountResponse.Data();
	    String acLogin;
	    String ssh;
	    String home;

	    String uid = new String();
	    String mid = new String();

	    try {
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new DBERRORMessage("query failed");
		}
		// Building the list
		do {
		    ListLocalAccountResponse.Data.Localaccount account = new ListLocalAccountResponse.Data.Localaccount();
		    acLogin = rs.getString(2);
		    ssh = rs.getString(3);
		    home = rs.getString(4);
		    uid = rs.getString(7);
		    mid = rs.getString(8);

		    account.setUserId(uid);
		    account.setMachineId(mid);
		    account.setAcLogin(acLogin);
		    account.setSshKeyPath(ssh);
		    account.setHomeDirectory(home);
		    data.getLocalaccount().add(account);
		}while (rs.next());
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    rep.setData(data);

	    return rep;
	}

	public DeleteLocalAccountResponse deleteLocalAccount(
							     DeleteLocalAccountRequest parameters) throws SESSIONKEYNOTFOUNDMessage, UNKNOWNLOCALACCOUNTMessage,  DBERRORMessage, SESSIONKEYEXPIREDMessage {
	    
	    // Check if session key is valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		System.out.println ("Invalid session key");
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Get sessions to remove
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String localUID;
	    String machineId;
	    String sqlText = "SELECT * FROM sessions where sessionkey = '" + parameters.getSessionKey()+"'";
	    try {
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new DBERRORMessage("query failed");
		}
		localUID = rs.getString(9);
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    // Get machine id
	    String machine = "SELECT * FROM machine where machineid = '" + parameters.getMachineId() + "'";
	    try {
		rs = sql.executeQuery(machine);
		if (!rs.next()){
		    throw new UNKNOWNLOCALACCOUNTMessage("Invalid parameter");
		}
		machineId = rs.getString(1);
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    // Remove account
	    String remove = "DELETE FROM \"account\" where numuserid = '"+localUID+"' AND numMachineID = '"+machineId+"'";
	    try {
	    	sql.execute(remove);
	    }catch (SQLException e){
		throw new DBERRORMessage ("Query failed", e);
	    }
	    DeleteLocalAccountResponse rep = new DeleteLocalAccountResponse();
	    return rep;
	}

	public ConnectResponse connect(ConnectRequest parameters)
	    throws 
		   NOADMINMessage, DBERRORMessage,
		   INCORRECTTIMEOUTMessage, UNKNOWNCLOSUREMODEMessage,
		   NOTAUTHENTICATEDMessage {
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Check login and password
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String localUID;
	    String numUID;
	    int size;
	    String sqlText = "SELECT * FROM users where userid = '" + parameters.getUserId()+"'";
	    try {
		rs = sql.executeQuery(sqlText);
	    }catch(SQLException e){
		throw new DBERRORMessage("query failed", e);
	    }
	    boolean toto;
	    try {
		toto = rs.next();
	    }catch(SQLException e){
		throw new DBERRORMessage("query failed", e);
	    }
	    if (!toto){
		throw new NOTAUTHENTICATEDMessage("Invalid parameter");
	    }
	    try{
		localUID = rs.getString(2);
		numUID   = rs.getString(1);
		if (rs.getString(3).compareTo(parameters.getPassword())!=0){
		    throw new NOTAUTHENTICATEDMessage("Invalid password");
		}
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    
	    // Generate session key
	    String tmp = "SELECT * from sessions";
	    try{
		rs = sql.executeQuery(tmp);
		size = 0;
		while (rs.next()){
		    size++;
		}
	    }
	    catch (SQLException e){
		throw new DBERRORMessage("query failed", e);
	    }
	    String key = localUID+"_"+size;
	    // Create new session in DB
	    String addSession = "INSERT into sessions(\"lastconnect\", \"creation\", \"sessionkey\", \"states\", \"closepolicy\", \"timeoutdate\", \"numuserid\") values('100', '100', '" + key + "', 'ACTIVE', '"+parameters.getClosePolicy()+"', '"+parameters.getSessionInactivityDelay()+"', '" + numUID + "')";
	    try {
		sql.execute(addSession);
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    ConnectResponse rep = new ConnectResponse();
	    rep.setSessionKey(key);
	    // Return session key
	    return rep;
	}


	public CloseResponse close(CloseRequest parameters)
	    throws SESSIONKEYNOTFOUNDMessage, DBERRORMessage,
		   SESSIONKEYEXPIREDMessage, COMMANDRUNNINGMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    String sqlText = "SELECT * FROM sessions WHERE sessionKey='"+parameters.getSessionKey()+"'";
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String num         = new String();
	    String sessionid   = new String();
	    String lastC       = new String();
	    String creation    = new String();
	    String state       = new String();
	    String closePolicy = new String();
	    String timeout     = new String();
	    String id          = new String();
	    try{
		rs = sql.executeQuery(sqlText);
		if (!rs.next())
		    throw new DBERRORMessage("Invalid exception");
		num         = rs.getString(1);
		sessionid   = rs.getString(2);
		lastC       = rs.getString(3);
                creation    = rs.getString(4);
		state       = "INACTIVE";
                closePolicy = rs.getString(7);
                timeout     = rs.getString(8);
		id          = rs.getString(9);
	    }catch(SQLException e){
	    	System.out.println("Failed to get user corresponding to the session key with : "+sqlText);
	    }
	    String req = "UPDATE sessions SET \"sessionid\"='"+sessionid+"', \"lastconnect\"='"+lastC+"', \"creation\"='"+creation+"', \"sessionkey\"='"+parameters.getSessionKey()+"', \"states\"='"+state+"', \"closepolicy\"='"+closePolicy+"', \"timeoutdate\"='"+timeout+"', \"numuserid\"='"+id+"' WHERE numsessionid='"+num+"'" ;
	    try{
		sql.execute(req);
	    }catch(SQLException e){
		throw new DBERRORMessage("db update failed", e);
	    }
	    CloseResponse rep = new CloseResponse();
	    return rep;
	}

	public ListSessionsResponse listSessions(ListSessionsRequest parameters)
	    throws UNKNOWNSESSIONOPTIONMessage,
		   SESSIONKEYNOTFOUNDMessage, INCORRECTDATEOPTIONMessage, SESSIONKEYEXPIREDMessage, DBERRORMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Get sessions from db to build the list
	    Statement sql = db.createStatement();
	    ResultSet rs;
	   // Getting id of the user to get session from
	    String id = "0";
	    String req = "SELECT * FROM sessions WHERE sessionkey = '"+parameters.getSessionKey()+"'"; 
	    try{
		rs = sql.executeQuery(req);
		if (!rs.next())
		    throw new DBERRORMessage("Session key failed to be found");
		id = rs.getString(9);
	    }catch(SQLException e){
		throw new DBERRORMessage("Session key failed to be found", e);
	    }

	    String sqlText = "SELECT sessions.*, users.userid FROM sessions, users WHERE sessions.numuserid = users.numuserid AND sessions.numuserid = "+id;
	    ListSessionsResponse rep = new ListSessionsResponse();
	    ListSessionsResponse.Data data = new ListSessionsResponse.Data();
	    Long             lastC;
	    Long             creation;
	    String           sessionKey;
	    SessionStateType state;
	    SessionCloseType closePolicy;
	    Long             timeout;
	    String           uid;

	    try {
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new DBERRORMessage("query failed");
		}
		do {
		    ListSessionsResponse.Data.Session session = new ListSessionsResponse.Data.Session();
		    
		    lastC = new Long(rs.getString(3));
		    creation = new Long(rs.getString(4));
		    sessionKey = rs.getString(5);
		    state = SessionStateType.fromValue((rs.getString(6)));
		    closePolicy = SessionCloseType.fromValue(rs.getString(7));
		    timeout = rs.getLong(8);
		    uid = rs.getString(10);

		    session.setUserId(uid);
		    session.setDateLastConnect(lastC);
		    session.setDateCreation(creation);
		    session.setSessionKey(sessionKey);
		    session.setState(state);
		    session.setClosePolicy(closePolicy);
		    session.setTimeout(timeout);

		    data.getSession().add(session);
		}while (rs.next());
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    rep.setData(data);

	    return rep;
	}



	public ChangePasswordResponse changePassword(
						     ChangePasswordRequest parameters) throws  DBERRORMessage, DBERRORMessage, NOTAUTHENTICATEDMessage {
	    
	    // Check username and pwd
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Check login and password
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String numUser = new String();
	    String sqlText = "SELECT * FROM users where userid = '" + parameters.getUserId()+"'";
	    try {
		// Getting the num ID of the corresponding user
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new SQLException("Invalid parameter");
		}
		numUser = rs.getString(1);
		// Checking the password is correct
		if (rs.getString(3).compareTo(parameters.getPassword()) != 0){
		    throw new SQLException("Invalid parameter");
		}
		
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);
	    }
	    // Update with new pwd
	    String update = "UPDATE \"users\" set \"password\"= '"+parameters.getPasswordNew()+"' where numUserID= '"+numUser+"'";
	    try {
		sql.execute(update);
	    } catch (SQLException e) {
		throw new DBERRORMessage("query failed", e);  
	    }
	    ChangePasswordResponse rep = new ChangePasswordResponse();
	    return rep;
	}
    
	private boolean isSessionKeyValid (String key)  throws DBERRORMessage{
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
    		throw new DBERRORMessage("db connection failed", e); 
	    }
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String sqlText = "SELECT * FROM sessions where sessionkey = '" +key+"'";
	    try {
		rs = sql.executeQuery(sqlText);
		if (rs.next())
		    return true;
	    }catch(SQLException e){
    		return false;
	    }
	    return false;
	}



	public VishnuFinalizeResponse vishnuFinalize(VishnuFinalizeRequest arg0) {
	    // TODO Auto-generated method stub
	    return null;
	}

	public VishnuInitializeResponse vishnuInitialize(
							 VishnuInitializeRequest arg0) {
	    // TODO Auto-generated method stub
	    return null;
	}

	public AddLocalAccountResponse addLocalAccount(
			AddLocalAccountRequest parameters)
			throws UMSSERVERNOTAVAILABLEMessage, VISHNUOKMessage,
			LOCALACCOUNTEXISTMessage, UNKNOWNMACHINEMessage,
			SESSIONKEYNOTFOUNDMessage, DBERRORMessage, UNKNOWNUSERIDMessage,
			SESSIONKEYEXPIREDMessage, MACHINEIDREQUIREDMessage,
			USERIDREQUIREDMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		System.out.println ("Invalid session key");
		throw new SESSIONKEYNOTFOUNDMessage("Invalid sessionkey");
	    }
	    // Check username and pwd
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new DBERRORMessage("db connection failed", e);
	    }
	    // Check login and password
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String numUser = new String();
	    String numMach = new String();
	    String userText = "SELECT * FROM users where userid = '" + parameters.getUserId()+"'";
	    String machText = "SELECT * FROM machine where machineid = '" + parameters.getMachineId()+"'";
	    try {
		// Getting the num ID of the corresponding user
		System.out.println ("Req : ->"+userText+"<-");
		rs = sql.executeQuery(userText);
		if (!rs.next()){
		    System.out.println ("Invalid User id");
		    throw new UNKNOWNUSERIDMessage("Invalid parameter");
		}
		numUser = rs.getString(1);
		System.out.println ("Req : ->"+machText+"<-");
		// Getting the machine ID of the corresponding machine
		rs = sql.executeQuery(machText);
		if (!rs.next()){
		    System.out.println ("Invalid Machine id");
		    throw new UNKNOWNMACHINEMessage("Invalid parameter");
		}
		numMach = rs.getString(1);
	    }catch (SQLException e){
		System.out.println ("Fail to get the machine or user id");
		throw new UNKNOWNUSERIDMessage("Invalid parameter");
	    }

	    // Inserting in the account table	    
	    String insertAcc = "INSERT into account (\"aclogin\", \"sshpathkey\", \"homedirectory\", \"numuserid\", \"nummachineid\") values('"+parameters.getAcLogin()+"', '"+parameters.getSshKeyPath()+"', '"+parameters.getHomeDirectory()+"', '"+numUser+"', '"+numMach+"')";
	    try {
		System.out.println("Req : ->"+insertAcc+"<-");
		sql.execute(insertAcc);
	    }catch (SQLException e){
		System.out.println ("Fail to insert in the account table");
		throw new DBERRORMessage("Insert error");
	    }
	    AddLocalAccountResponse rep = new AddLocalAccountResponse();
	    return rep;
	}
    
    }
