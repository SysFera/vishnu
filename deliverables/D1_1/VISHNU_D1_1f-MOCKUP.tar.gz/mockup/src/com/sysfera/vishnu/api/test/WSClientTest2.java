package com.sysfera.vishnu.api.test;

import com.sysfera.vishnu.api.tms.GetAllJobsOutPutRequest;
import com.sysfera.vishnu.api.tms.GetAllJobsOutPutResponse;
import com.sysfera.vishnu.api.tms.CancelJobRequest;
import com.sysfera.vishnu.api.tms.CancelJobResponse;
import com.sysfera.vishnu.api.tms.GetJobOutPutRequest;
import com.sysfera.vishnu.api.tms.GetJobOutPutResponse;
import com.sysfera.vishnu.api.tms.GetJobProgressRequest;
import com.sysfera.vishnu.api.tms.GetJobProgressResponse;
import com.sysfera.vishnu.api.tms.ListQueuesRequest;
import com.sysfera.vishnu.api.tms.ListQueuesResponse;
import com.sysfera.vishnu.api.tms.ListJobsRequest;
import com.sysfera.vishnu.api.tms.ListJobsResponse;
import com.sysfera.vishnu.api.tms.SubmitJobRequest;
import com.sysfera.vishnu.api.tms.GetJobInfoRequest;
import com.sysfera.vishnu.api.tms.GetJobInfoResponse;
import com.sysfera.vishnu.api.tms.TMSBATCHSCHEDULERERRORMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDPATHMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDREQUESTMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDRESPONSEMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDSESSIONKEYMessage;
import com.sysfera.vishnu.api.tms.TMSPERMISSIONDENIEDMessage;
import com.sysfera.vishnu.api.tms.TMSSERVERNOTAVAILABLEMessage;
import com.sysfera.vishnu.api.tms.TMSSUBMITSERVICENOTAVAILABLEMessage;
import com.sysfera.vishnu.api.tms.TMSUNKNOWNBATCHSCHEDULERTYPEMessage;
import com.sysfera.vishnu.api.tms.TMSUNKNOWNMACHINEMessage;
import com.sysfera.vishnu.api.tms.TMSUNKNOWNQUEUEMessage;
import com.sysfera.vishnu.api.tms.VishnuTMSPortType;
import com.sysfera.vishnu.api.ums.VishnuUMSPortType;



import java.util.ListIterator;


/**
 * Test API WS - Use case 2 : job submission
 * @author bisnard
 *
 */
public class WSClientTest2 {
	
	VishnuUMSPortType UMSPort;
	VishnuTMSPortType TMSPort;
	
	public WSClientTest2(VishnuUMSPortType port1, VishnuTMSPortType port2) {
		UMSPort = port1;
		TMSPort = port2;
	}
	
	public int run() {
		
		System.out.println("TEST 2 : START");
		
		// Create ws request object
		SubmitJobRequest request = new SubmitJobRequest();
		GetJobInfoRequest reqI = new GetJobInfoRequest();
		ListJobsRequest reqLJ = new ListJobsRequest();
		ListQueuesRequest reqLQ = new ListQueuesRequest();
		GetJobProgressRequest reqP = new GetJobProgressRequest();
		GetJobOutPutRequest reqO = new GetJobOutPutRequest();
		GetAllJobsOutPutRequest reqOA = new GetAllJobsOutPutRequest();
		CancelJobRequest reqC = new CancelJobRequest();
		request.setSessionKey("ben_0");
		request.setMachineId("1");
		request.setScriptFilePath("/bin/ls");
		
		// Call the web service
		try {
		    // SUBMIT JOB
		    System.out.println("Test Submit job :");
		    TMSPort.submitJob(request);
		    System.out.println("Test Submit job : DONE");
		    // GET INFO
		    System.out.println("Test Get job info :");
		    reqI.setSessionKey(request.getSessionKey());
		    reqI.setMachineId("machine0");
		    reqI.setJobId("1");
		    GetJobInfoResponse respI = TMSPort.getJobInfo(reqI);
		    System.out.println("Info for the job : ");
		    System.out.println("Session : "+respI.getSessionId());
		    System.out.println("JobName : "+respI.getJobName());
		    System.out.println("MachineId : "+respI.getSubmitMachineId());
		    System.out.println("MachineName : "+respI.getSubmitMachineName());
		    System.out.println("Job desc : "+respI.getJobDescription());
		    System.out.println("Test Get job info : DONE");
		    // LIST JOB
		    System.out.println("Test list job :");
		    reqLJ.setSessionKey(request.getSessionKey());
		    reqLJ.setMachineId("machine0");
		    ListJobsResponse respLJ = TMSPort.listJobs(reqLJ);
		    ListIterator<ListJobsResponse.Data.Job> listj = respLJ.getData().getJob().listIterator();
		    ListJobsResponse.Data.Job j;
		    while(listj.hasNext()){
			j = listj.next();
			System.out.println ("Job id : "+j.getJobId()+", job state = "+j.getStatus()+", path = "+j.getJobPath()+", description : "+j.getJobDescription());
			listj.remove();
		    }
		    System.out.println("Test list job : DONE");
		    // LIST QUEUE
		    System.out.println("Test list queue :");
		    reqLQ.setSessionKey(request.getSessionKey());
		    reqLQ.setMachineId("machine0");
		    ListQueuesResponse respLQ = TMSPort.listQueues(reqLQ);
		    ListIterator<ListQueuesResponse.Data.Queue> listq = respLQ.getData().getQueue().listIterator();
		    ListQueuesResponse.Data.Queue q;
		    while(listq.hasNext()){
			q = listq.next();
			System.out.println ("Queue name : "+q.getName()+", max job/cpu = "+q.getMaxJobCpu()+", memory = "+q.getMemory()+", status : "+q.getState()+", priority : "+q.getPriority()+", desc : "+q.getDescription());
			listq.remove();
		    }
		    System.out.println("Test list job : DONE");
		    // GET PROGRESS
		    System.out.println("Test Get job progress :");
		    reqP.setSessionKey(request.getSessionKey());
		    reqP.setMachineId("machine0");
		    reqP.setJobId("1");
		    GetJobProgressResponse respP = TMSPort.getJobProgress(reqP);
		    System.out.println("Info for the progress : ");
		    System.out.println("Job id : "+respP.getJobId());
		    System.out.println("JobName : "+respP.getJobName());
		    System.out.println("Wall time : "+respP.getWallTime());
		    System.out.println("Percent : "+respP.getPercent());
		    System.out.println("status : "+respP.getStatus());
		    System.out.println("Test Get job progress : DONE");
		    // GET OUTPUT
		    System.out.println("Test Get job output :");
		    reqO.setSessionKey(request.getSessionKey());
		    reqO.setMachineId("machine0");
		    reqO.setJobId("1");
		    GetJobOutPutResponse respO = TMSPort.getJobOutPut(reqO);
		    System.out.println("Info for the output : ");
		    System.out.println("stdout : "+respO.getOutputPath());
		    System.out.println("stderr : "+respO.getErrorPath());
		    System.out.println("Test Get job output : DONE");
		    // GET ALL OUTPUT
		    System.out.println("Test get all output :");
		    reqOA.setSessionKey(request.getSessionKey());
		    reqOA.setMachineId("machine0");
		    GetAllJobsOutPutResponse respOA = TMSPort.getAllJobsOutPut(reqOA);
		    ListIterator<GetAllJobsOutPutResponse.Data.Jobresult> listoa = respOA.getData().getJobresult().listIterator();
		    GetAllJobsOutPutResponse.Data.Jobresult oa;
		    while(listoa.hasNext()){
			oa = listoa.next();
			System.out.println("Job id : "+ oa.getJobId());
			System.out.println("stdout : "+oa.getOutputPath());
			System.out.println("stderr : "+oa.getErrorPath());
			listoa.remove();
		    }
		    System.out.println("Test get all output : DONE");
		    // CANCEL
		    System.out.println("Test cancel :");
		    reqC.setSessionKey(request.getSessionKey());
		    reqC.setMachineId("machine0");
		    reqC.setJobId("1");
		    CancelJobResponse respC = TMSPort.cancelJob(reqC);
		    System.out.println("Cancel test : "+respC.getInfoMsg());
		    System.out.println("Test cancel : DONE");
		    System.out.println("TEST 2 : OK");
		    return 0;
		} catch (TMSSERVERNOTAVAILABLEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSPERMISSIONDENIEDMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSINVALIDREQUESTMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSUNKNOWNMACHINEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSUNKNOWNBATCHSCHEDULERTYPEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSBATCHSCHEDULERERRORMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSSUBMITSERVICENOTAVAILABLEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSUNKNOWNQUEUEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSINVALIDPATHMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSINVALIDRESPONSEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TMSINVALIDSESSIONKEYMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}catch (Exception e){
			e.printStackTrace();
		}
		System.out.println("TEST 2 : FAILED");
		return 1;
	}
	
}
