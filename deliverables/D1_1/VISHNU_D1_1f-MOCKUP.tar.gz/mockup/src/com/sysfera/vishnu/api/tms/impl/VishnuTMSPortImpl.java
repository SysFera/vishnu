package com.sysfera.vishnu.api.tms.impl;

import com.sysfera.vishnu.api.mockup.Database;
import com.sysfera.vishnu.api.tms.CancelJobRequest;
import com.sysfera.vishnu.api.tms.JobPriority;
import com.sysfera.vishnu.api.tms.JobStatus;
import com.sysfera.vishnu.api.tms.CancelJobResponse;
import com.sysfera.vishnu.api.tms.GetAllJobsOutPutRequest;
import com.sysfera.vishnu.api.tms.GetAllJobsOutPutResponse;
import com.sysfera.vishnu.api.tms.GetJobInfoRequest;
import com.sysfera.vishnu.api.tms.GetJobInfoResponse;
import com.sysfera.vishnu.api.tms.GetJobOutPutRequest;
import com.sysfera.vishnu.api.tms.GetJobOutPutResponse;
import com.sysfera.vishnu.api.tms.GetJobProgressRequest;
import com.sysfera.vishnu.api.tms.GetJobProgressResponse;
import com.sysfera.vishnu.api.tms.ListJobsRequest;
import com.sysfera.vishnu.api.tms.ListJobsResponse;
import com.sysfera.vishnu.api.tms.ListQueuesRequest;
import com.sysfera.vishnu.api.tms.ListQueuesResponse;
import com.sysfera.vishnu.api.tms.QueueStatus;
import com.sysfera.vishnu.api.tms.QueuePriority;
import com.sysfera.vishnu.api.tms.SubmitJobRequest;
import com.sysfera.vishnu.api.tms.SubmitJobResponse;
import com.sysfera.vishnu.api.tms.TMSBATCHSCHEDULERERRORMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDPATHMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDREQUESTMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDRESPONSEMessage;
import com.sysfera.vishnu.api.tms.TMSINVALIDSESSIONKEYMessage;
import com.sysfera.vishnu.api.tms.TMSPERMISSIONDENIEDMessage;
import com.sysfera.vishnu.api.tms.TMSSERVERNOTAVAILABLEMessage;
import com.sysfera.vishnu.api.tms.TMSSUBMITSERVICENOTAVAILABLEMessage;
import com.sysfera.vishnu.api.tms.TMSUNKNOWNBATCHSCHEDULERTYPEMessage;
import com.sysfera.vishnu.api.tms.TMSUNKNOWNMACHINEMessage;
import com.sysfera.vishnu.api.tms.TMSUNKNOWNQUEUEMessage;
import com.sysfera.vishnu.api.tms.VishnuTMSPortType;

import java.sql.*;
import java.lang.Double;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.jws.WebService;
import java.math.BigInteger;

@WebService(targetNamespace = "urn:ResourceProxy", name = "VishnuTMS", serviceName="VishnuTMSService")
@Remote(VishnuTMSPortType.class)
@Stateless
public class VishnuTMSPortImpl implements VishnuTMSPortType {

    public GetJobInfoResponse getJobInfo(GetJobInfoRequest parameters)
	throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
	       TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
	       TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
	       TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {

	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }

	    String sqlText = "SELECT job.*, file.*, commands.*, machine.*, sessions.* FROM job, file, commands, machine, sessions WHERE file.numcommandid = commands.numcommandid AND machine.machineid = '"+parameters.getMachineId()+"' AND job.jobid= '"+parameters.getJobId()+"' AND job.numcommandid = commands.numcommandid AND commands.nummachineid = machine.nummachineid";
	    // Check username and pwd
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new TMSINVALIDRESPONSEMessage("db connection failed", e);
	    }
	    // Check login and password
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    GetJobInfoResponse rep = new GetJobInfoResponse();

	    String    sid;
	    String    mid;
	    String    jid;
	    String    jname;
	    String    jpath;
	    String    opath;
	    String    erpath;
//	    String    prio;
	    String    cpunbr;
	    String    workDir;
	    JobStatus v;
	    Long      start;
	    Long      end;
	    String    owner;
	    String    queue;
	    String    wall;
	    String    group;
	    String    desc;
	    String    mem;
	    String    node;
	    String    nodeAndCpu;
//	    String    type;
	    String    mname;
	    try {
		// Getting the num ID of the corresponding user
		rs = sql.executeQuery(sqlText);
		if (!rs.next()){
		    throw new TMSINVALIDRESPONSEMessage("Invalid parameter");
		}
		jid = rs.getString(2);
		v   = JobStatus.valueOf(rs.getString(3));
		jpath = rs.getString(4);
		opath = rs.getString(5);
		erpath  = rs.getString(6);
		workDir = rs.getString(7);
		start      = new Long(rs.getString(15));
		end        = new Long(rs.getString(16));
		desc   	   = rs.getString(17);
//		type       = rs.getString(18);
		mid 	   = rs.getString(22);
		mname      = rs.getString(23);
		sid 	   = rs.getString(30);    
	    }catch (SQLException e){
		throw new TMSINVALIDRESPONSEMessage("Invalid parameter");
	    }
	    
	    jname      = "JobTest1";
//	    prio       = "High";
	    cpunbr 	   = "4";
	    queue  	   = "toto";
	    wall   	   = "100";
	    group  	   = "users";
	    mem    	   = "300";
	    node   	   = "6";
	    nodeAndCpu 	   = "3 4";
	    owner      	   = "Ownage";
	    rep.setJobId(jid);
	    rep.setJobPath(jpath);
	    rep.setStatus(v);
	    rep.setOutputPath(opath);
	    rep.setErrorPath(erpath);
	    rep.setJobWorkingDir(workDir);
	    rep.setSessionId(sid);
	    rep.setSubmitMachineId(mid);
	    rep.setSubmitMachineName(mname);
	    rep.setJobName(jname);
	    rep.setJobPrio(JobPriority.HIGH);
	    rep.setNbCpus(new BigInteger(cpunbr));
	    rep.setSubmitDate(start);
	    rep.setEndDate(end);
	    rep.setOwner(owner);
	    rep.setJobQueue(queue);
	    rep.setWallClockLimit(new Long(wall));
	    rep.setGroupName(group);
	    rep.setJobDescription(desc);
	    rep.setMemLimit(new BigInteger(mem));
	    rep.setNbNodes(new BigInteger(node));
	    rep.setNbNodesAndCpuPerNode(nodeAndCpu);
	    return rep;
	}

	public ListJobsResponse listJobs(ListJobsRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
			TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
			TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
			TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new TMSINVALIDRESPONSEMessage("db connection failed", e);
	    }
	    // Check login and password
	    Statement sql = db.createStatement();
	    ResultSet rs;

	    ListJobsResponse rep = new ListJobsResponse();
	    ListJobsResponse.Data data = new ListJobsResponse.Data();

	    String req = "SELECT DISTINCT job.*, file.*, commands.* FROM job, file, commands, machine WHERE machine.machineid ='"+parameters.getMachineId()+"' AND machine.nummachineid = commands.nummachineid AND job.numcommandid = commands.numcommandid AND file.numcommandid = commands.numcommandid";

	    try{
		rs = sql.executeQuery(req);
		if (!rs.next()){
		    throw new TMSINVALIDRESPONSEMessage("Query failed");
		}
		do{
		    ListJobsResponse.Data.Job j = new ListJobsResponse.Data.Job();
		    j.setJobId(rs.getString(2));
		    j.setStatus(JobStatus.valueOf(rs.getString(3)));
		    j.setJobPath(rs.getString(4));
		    j.setJobDescription(rs.getString(17));
		    data.getJob().add(j);
		}while(rs.next());
	    }catch (SQLException e){
		throw new TMSINVALIDRESPONSEMessage("Query failed");
	    }
	    rep.setData(data);
	    return rep;
	}

	public SubmitJobResponse submitJob(SubmitJobRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
			TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
			TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
			TMSSUBMITSERVICENOTAVAILABLEMessage, TMSUNKNOWNQUEUEMessage,
			TMSINVALIDPATHMessage, TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {
		
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }

	    SubmitJobResponse rep = new SubmitJobResponse();
	    rep.setJobId("JOB36");
	    rep.setJobPath("/tmp/job36");
	    
	    Database db = null;
	    ResultSet rs;
	    Statement sql = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new TMSSERVERNOTAVAILABLEMessage("", e);
	    }
	    sql = db.createStatement();
	    // Database INSERT query
	    // Note: creation de la table:
	    // create table jobs (id SERIAL PRIMARY KEY, path varchar(20));
	    String tmp = "SELECT * from job";
	    int size;
	    size = 1; // init at 1 to have valid id
	    try{
		rs = sql.executeQuery(tmp);
		while (rs.next()){
		    size++;
		}
	    }
	    catch (SQLException e){
		throw new TMSINVALIDREQUESTMessage("query failed", e);
	    }
	    
	    String sqlcomm = "INSERT INTO commands(\"commandid\", \"starttime\", \"endtime\", \"cmddescription\", \"cmdtype\", \"nummachineid\", \"numsessionid\") values('1', '150', '-1', 'testScript', 'T', '1', '1')";
	    String sqljob  = "INSERT INTO job(\"jobid\", \"jobstate\", \"jobpath\", \"joboutputpath\", \"joberrorpath\", \"submitdir\", \"numcommandid\") values ('"+size+"', 'RUNNING', '/home/toto', '/home/toto', '/home/toto', '/home/toto', '"+size+"')";
	    String sqlfile = "INSERT INTO file(\"namefile\", \"content\", \"numcommandid\") values('launchStricp', 'contentOfFile', '"+size+"')";
	    try {
		
		sql = db.createStatement();
		sql.execute(sqlcomm);
		sql.execute(sqljob);
		sql.execute(sqlfile);
	    } catch (SQLException e) {
		System.out.println("comm : "+sqlcomm);
		System.out.println("comm : "+sqljob);
		System.out.println("comm : "+sqlfile);
		throw new TMSINVALIDREQUESTMessage("Invalid request");
	    }
	    return rep;
	}
    
    public ListQueuesResponse listQueues(ListQueuesRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
			TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
			TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
			TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }
//	    Database db = null;
//	    try {
//		db = Database.getInstance();
//	    } catch (RuntimeException e) {
//		throw new TMSINVALIDRESPONSEMessage("db connection failed", e);
//	    }
	    // Check login and password
//	    Statement sql = db.createStatement();
//	    ResultSet rs;

	    ListQueuesResponse rep = new ListQueuesResponse();
	    ListQueuesResponse.Data data = new ListQueuesResponse.Data();

	    ListQueuesResponse.Data.Queue q = new ListQueuesResponse.Data.Queue();
	    q.setName("q1");
	    q.setMaxJobCpu(new BigInteger("2"));
	    q.setMemory(new BigInteger("3400"));
	    q.setState(QueueStatus.STARTED);
	    q.setPriority(QueuePriority.HIGH);
	    q.setDescription("The first queue");
	    data.getQueue().add(q);

	    q = new ListQueuesResponse.Data.Queue();
	    q.setName("q2");
	    q.setMaxJobCpu(new BigInteger("3"));
	    q.setMemory(new BigInteger("3600"));
	    q.setState(QueueStatus.NOT_AVAILABLE);
	    q.setPriority(QueuePriority.VERY_LOW);
	    q.setDescription("The Second queue");
	    data.getQueue().add(q);

	    q = new ListQueuesResponse.Data.Queue();
	    q.setName("q3");
	    q.setMaxJobCpu(new BigInteger("1"));
	    q.setMemory(new BigInteger("3100"));
	    q.setState(QueueStatus.RUNNING);
	    q.setPriority(QueuePriority.NORMAL);
	    q.setDescription("The last queue");
	    data.getQueue().add(q);

	    rep.setData(data);
	    return rep;
	}

	public GetJobProgressResponse getJobProgress(
			GetJobProgressRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSINVALIDREQUESTMessage,
			TMSUNKNOWNMACHINEMessage, TMSSUBMITSERVICENOTAVAILABLEMessage,
			TMSINVALIDSESSIONKEYMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }

	    GetJobProgressResponse rep = new GetJobProgressResponse();
	    rep.setJobId("1");
	    rep.setJobName("jobName");
	    rep.setWallTime(new BigInteger("100"));
	    rep.setPercent(new Double("35.69"));
	    rep.setStatus(JobStatus.RUNNING);
	    return rep;
	}

	public GetJobOutPutResponse getJobOutPut(GetJobOutPutRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
			TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
			TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
			TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    ResultSet rs;
	    Statement sql = null;
	    GetJobOutPutResponse rep = new GetJobOutPutResponse();

	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new TMSSERVERNOTAVAILABLEMessage("", e);
	    }
	    sql = db.createStatement();
	    String req = "SELECT job.* from job, commands, machine WHERE commands.numcommandid = job.numcommandid AND commands.nummachineid = machine.nummachineid AND machine.machineid ='"+parameters.getMachineId()+"' AND job.jobid ='"+parameters.getJobId()+"'";

	    try{
	    	rs = sql.executeQuery(req);
		if (!rs.next()){
		    throw new TMSINVALIDRESPONSEMessage("Invalid parameters, no result found");
		}
		rep.setOutputPath(rs.getString(5));
		rep.setErrorPath(rs.getString(6));
	    }catch(SQLException e){
		throw new TMSINVALIDRESPONSEMessage("Query failed", e);
	    }
	    return rep;
	}

	public GetAllJobsOutPutResponse getAllJobsOutPut(
			GetAllJobsOutPutRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
			TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
			TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
			TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }
	    Database db = null;
	    ResultSet rs;
	    Statement sql = null;
	    GetAllJobsOutPutResponse rep = new GetAllJobsOutPutResponse();
	    GetAllJobsOutPutResponse.Data data = new GetAllJobsOutPutResponse.Data();
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
		throw new TMSSERVERNOTAVAILABLEMessage("", e);
	    }
	    sql = db.createStatement();
	    String req = "SELECT job.* from job, commands, machine WHERE commands.numcommandid = job.numcommandid AND commands.nummachineid = machine.nummachineid AND machine.machineid ='"+parameters.getMachineId()+"'";

	    try{
		rs = sql.executeQuery(req);
		if (!rs.next()){
		    throw new TMSINVALIDRESPONSEMessage("Query failed");
		}
		do{
		    GetAllJobsOutPutResponse.Data.Jobresult r = new GetAllJobsOutPutResponse.Data.Jobresult();
		    r.setJobId(rs.getString(2));
		    r.setOutputPath(rs.getString(5));
		    r.setErrorPath(rs.getString(6));
		    data.getJobresult().add(r);
		}while(rs.next());
	    }catch (SQLException e){
		throw new TMSINVALIDRESPONSEMessage("Query failed");
	    }
	    rep.setData(data);
	    return rep;
	    
	}

	public CancelJobResponse cancelJob(CancelJobRequest parameters)
			throws TMSSERVERNOTAVAILABLEMessage, TMSPERMISSIONDENIEDMessage,
			TMSINVALIDREQUESTMessage, TMSUNKNOWNMACHINEMessage,
			TMSUNKNOWNBATCHSCHEDULERTYPEMessage, TMSBATCHSCHEDULERERRORMessage,
			TMSINVALIDRESPONSEMessage, TMSINVALIDSESSIONKEYMessage {
	    // Check session key valid
	    if (!isSessionKeyValid(parameters.getSessionKey())){
		throw new TMSINVALIDSESSIONKEYMessage("Invalid sessionkey");
	    }
	    CancelJobResponse rep = new CancelJobResponse();
	    rep.setInfoMsg("Job cancelled with success");
	    return rep;
	}
    
	private boolean isSessionKeyValid (String key)  {
	    Database db = null;
	    try {
		db = Database.getInstance();
	    } catch (RuntimeException e) {
	    	return false;
	    }
	    Statement sql = db.createStatement();
	    ResultSet rs;
	    String sqlText = "SELECT * FROM sessions where sessionkey = '" +key+"'";
	    try {
		rs = sql.executeQuery(sqlText);
		if (rs.next())
		    return true;
	    }catch(SQLException e){
    		return false;
	    }
	    return false;
	}

}
