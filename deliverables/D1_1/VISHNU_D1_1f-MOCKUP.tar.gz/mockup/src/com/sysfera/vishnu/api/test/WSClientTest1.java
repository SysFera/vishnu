package com.sysfera.vishnu.api.test;


import com.sysfera.vishnu.api.ums.ConnectRequest;
//import com.sysfera.vishnu.api.ums.ReconnectRequest;
import com.sysfera.vishnu.api.ums.SessionCloseType;
import com.sysfera.vishnu.api.ums.ConnectResponse;
//import com.sysfera.vishnu.api.ums.ReconnectResponse;
import com.sysfera.vishnu.api.ums.DBERRORMessage;
import com.sysfera.vishnu.api.ums.INCORRECTTIMEOUTMessage;
import com.sysfera.vishnu.api.ums.NOADMINMessage;
import com.sysfera.vishnu.api.ums.NOTAUTHENTICATEDMessage;
import com.sysfera.vishnu.api.ums.UNKNOWNCLOSUREMODEMessage;
import com.sysfera.vishnu.api.ums.VishnuUMSPortType;
import com.sysfera.vishnu.api.ums.UMSSERVERNOTAVAILABLEMessage;
import com.sysfera.vishnu.api.ums.VISHNUOKMessage;
import com.sysfera.vishnu.api.ums.AddLocalAccountRequest;
import com.sysfera.vishnu.api.ums.UpdateLocalAccountRequest;
import com.sysfera.vishnu.api.ums.DeleteLocalAccountRequest;
import com.sysfera.vishnu.api.ums.ChangePasswordRequest;
import com.sysfera.vishnu.api.ums.ListMachineRequest;
import com.sysfera.vishnu.api.ums.ListMachineResponse;
import com.sysfera.vishnu.api.ums.ListLocalAccountRequest;
import com.sysfera.vishnu.api.ums.ListLocalAccountResponse;
import com.sysfera.vishnu.api.ums.ListSessionsRequest;
import com.sysfera.vishnu.api.ums.ListSessionsResponse;
import com.sysfera.vishnu.api.ums.ListHistoryCmdRequest;
import com.sysfera.vishnu.api.ums.ListHistoryCmdResponse;
import com.sysfera.vishnu.api.ums.ListOptionsRequest;
import com.sysfera.vishnu.api.ums.ListOptionsResponse;
import com.sysfera.vishnu.api.ums.ConfigureOptionRequest;
import com.sysfera.vishnu.api.ums.CloseRequest;

import java.math.BigInteger;
import java.util.ListIterator;


/**
 * Test API WS - Use case 1 : authentification
 * @author bisnard
 *
 */
public class WSClientTest1 {
	
	VishnuUMSPortType UMSPort;
	
	public WSClientTest1(VishnuUMSPortType port1) {
		UMSPort = port1;
	}
	
	public int run() {
		
		System.out.println("TEST 1 : START");
		
		// Create ws request object
		ConnectRequest request = new ConnectRequest();
//		ReconnectRequest reco = new ReconnectRequest();
		AddLocalAccountRequest reqAcc = new AddLocalAccountRequest();
		UpdateLocalAccountRequest reqAccUp = new UpdateLocalAccountRequest();
		DeleteLocalAccountRequest reqAccDel = new DeleteLocalAccountRequest();
		ChangePasswordRequest reqP = new ChangePasswordRequest();
		ListMachineRequest reqListM = new ListMachineRequest();
		ListLocalAccountRequest reqListA = new ListLocalAccountRequest();
		ListSessionsRequest reqListS = new ListSessionsRequest();
		ListHistoryCmdRequest reqListH = new ListHistoryCmdRequest();
		ListOptionsRequest reqListO = new ListOptionsRequest();
		ListOptionsRequest reqListO2 = new ListOptionsRequest();
		ConfigureOptionRequest reqConf = new ConfigureOptionRequest();
		CloseRequest reqClo = new CloseRequest();
		request.setUserId("ben");
		request.setPassword("123");
		request.setSessionInactivityDelay(new BigInteger("10"));
		request.setClosePolicy(SessionCloseType.valueOf(new String("CLOSE_ON_TIMEOUT")));
		// Call the web service
		ConnectResponse resp;
		ListMachineResponse respListM;
		ListLocalAccountResponse respListA;
		ListSessionsResponse respListS;
		ListHistoryCmdResponse respListH;
		ListOptionsResponse respListO;
		ListOptionsResponse respListO2;
		try {
			System.out.println("TEST 1 : STARTING");
			// CONNECT
			System.out.println("Test connect :");
			resp = UMSPort.connect(request);
			System.out.println("SESSION KEY=" + resp.getSessionKey());
			System.out.println("Test connect : DONE");
			// CREATE ACCOUNT
			System.out.println("Test create local account :");
			reqAcc.setSessionKey(resp.getSessionKey());
			reqAcc.setUserId(request.getUserId());
			reqAcc.setMachineId("machine0");
			reqAcc.setAcLogin("toto");
			reqAcc.setSshKeyPath("/home/toto/.shh");
			reqAcc.setHomeDirectory("/home/toto");
			UMSPort.addLocalAccount(reqAcc);
			System.out.println("Test create local account : DONE");
			// LIST ACCOUNT
			System.out.println("Test list account :");
			reqListA.setSessionKey(resp.getSessionKey());
			respListA = UMSPort.listLocalAccount(reqListA);
			ListIterator<ListLocalAccountResponse.Data.Localaccount> listA = respListA.getData().getLocalaccount().listIterator();
			ListLocalAccountResponse.Data.Localaccount la;
			while(listA.hasNext()){
				la = listA.next();
				System.out.println ("User id : "+la.getUserId()+", machine id = "+la.getMachineId()+" ssh = "+la.getSshKeyPath());
				listA.remove();
			}
			System.out.println("Test list account : DONE");
			// UPDATE ACCOUNT
			System.out.println("Test Account update :");
			reqAccUp.setSessionKey(resp.getSessionKey());
			reqAccUp.setUserId(request.getUserId());
			reqAccUp.setMachineId(reqAcc.getMachineId());
			reqAccUp.setAcLogin("titi");
			UMSPort.updateLocalAccount(reqAccUp);
			System.out.println("Test Account update : DONE ");
			// DELETE ACCOUNT
			System.out.println("Test delete account :");
			reqAccDel.setSessionKey(resp.getSessionKey());
			reqAccDel.setUserId(request.getUserId());
			reqAccDel.setMachineId(reqAcc.getMachineId());			
			UMSPort.deleteLocalAccount(reqAccDel);
			System.out.println("Test delete account : DONE");
			// RECONNECT
//			System.out.println("Test reconnect :");
//			reco.setUserId_0020(request.getUserId());
//			reco.setUserId(request.getUserId());
//			reco.setPassword(request.getPassword());
//			reco.setSessionId("1");
//			respReco = UMSPort.reconnect(reco);
//			System.out.println("Session key gotten : "+respReco.getSessionKey());
//			System.out.println("Test reconnect : DONE");
			// CHANGE PWD
			System.out.println("Test change password :");
			reqP.setUserId(request.getUserId());
			reqP.setPassword(request.getPassword());
			reqP.setPasswordNew("456");
			UMSPort.changePassword(reqP);
			reqP.setPassword("456");
			reqP.setPasswordNew("123");
			UMSPort.changePassword(reqP);
			System.out.println("Test change password : DONE");
			// LIST MACHINE
			System.out.println("Test list machine : ");
			reqListM.setSessionKey(resp.getSessionKey());
			respListM = UMSPort.listMachine(reqListM);
			ListIterator<ListMachineResponse.Data.Machine> listm = respListM.getData().getMachine().listIterator();
			ListMachineResponse.Data.Machine m;
			while(listm.hasNext()){
				m = listm.next();
				System.out.println ("Machine name : "+m.getName()+", machine id = "+m.getMachineId()+" lieu = "+m.getSite());
				listm.remove();
			}
			System.out.println("Test list machine : DONE");
			// LIST SESSION
			System.out.println("Test list sessions :");
			reqListS.setSessionKey(resp.getSessionKey());
			respListS = UMSPort.listSessions(reqListS);
			ListIterator<ListSessionsResponse.Data.Session> listS = respListS.getData().getSession().listIterator();
			ListSessionsResponse.Data.Session ls;
			while(listS.hasNext()){
				ls = listS.next();
				System.out.println ("User id : "+ls.getUserId()+", session key  = "+ls.getSessionKey()+" timeout = "+ls.getTimeout());
				listS.remove();
			}
			System.out.println("Test list sessions : DONE");
			// LIST HISTORY
			System.out.println("Test list history :");
			reqListH.setSessionKey(resp.getSessionKey());
			respListH = UMSPort.listHistoryCmd(reqListH);
			ListIterator<ListHistoryCmdResponse.Data.Command> listH = respListH.getData().getCommand().listIterator();
			ListHistoryCmdResponse.Data.Command lh;
			while(listH.hasNext()){
				lh = listH.next();
				System.out.println ("Machine id : "+lh.getMachineId()+", session id  = "+lh.getSessionId()+", cmd = "+lh.getCommandId()+", description "+lh.getCmdDescription());
				listH.remove();
			}
			System.out.println("Test list history : DONE");
			// LIST OPTION
			System.out.println("Test list options :");
			reqListO.setSessionKey(resp.getSessionKey());
			respListO = UMSPort.listOptions(reqListO);
			ListIterator<ListOptionsResponse.Data.Optionvalue> listO = respListO.getData().getOptionvalue().listIterator();
			ListOptionsResponse.Data.Optionvalue lo;
			while(listO.hasNext()){
				lo = listO.next();
				System.out.println ("Name : "+lo.getOptionName()+", value : "+lo.getValue());
				listO.remove();
			}
			System.out.println("Test list options : DONE");
			// CONF OPTION
			System.out.println("Test conf option :");
			reqConf.setSessionKey(resp.getSessionKey());
			reqConf.setOptionName("Crepe");
			reqConf.setValue("Miam miam");
			reqListO2.setSessionKey(resp.getSessionKey());
			UMSPort.configureOption(reqConf);
			System.out.println("Affichage  de la liste des options, une option miam supp doit etre ajoutee");
			respListO2 = UMSPort.listOptions(reqListO2);
			ListIterator<ListOptionsResponse.Data.Optionvalue> listO2 = respListO2.getData().getOptionvalue().listIterator();
			ListOptionsResponse.Data.Optionvalue lo2;
			while(listO2.hasNext()){
				lo2 = listO2.next();
				System.out.println ("Name : "+lo2.getOptionName()+", value : "+lo2.getValue());
				listO2.remove();
			}
			System.out.println("Test conf option : DONE");
			// CLOSE
			System.out.println("Test close :");
			reqClo.setSessionKey(resp.getSessionKey());
			UMSPort.close(reqClo);
			System.out.println("Test close : DONE");
			// EOT (End Of Test)
			System.out.println("TEST 1 : DONE");
			return 0;
		} catch (DBERRORMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (VISHNUOKMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UMSSERVERNOTAVAILABLEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NOADMINMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (INCORRECTTIMEOUTMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UNKNOWNCLOSUREMODEMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NOTAUTHENTICATEDMessage e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println("TEST 1 : FAILED");
		return 1;
	}
	
}
