package com.sysfera.vishnu.api.vishnu.internal;

public class InternalFMSException extends Exception {
	public InternalFMSException(String s) {
		super(s);
	}
}
