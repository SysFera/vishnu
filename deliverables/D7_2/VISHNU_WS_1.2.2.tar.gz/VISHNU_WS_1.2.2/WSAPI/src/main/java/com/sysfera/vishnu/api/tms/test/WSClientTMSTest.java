package com.sysfera.vishnu.api.tms.test;

import static org.junit.Assert.*;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;

import org.junit.BeforeClass;
import org.junit.Test;

import com.sysfera.vishnu.api.tms.ALREADYCANCELEDMessage;
import com.sysfera.vishnu.api.tms.ALREADYDOWNLOADEDMessage;
import com.sysfera.vishnu.api.tms.ALREADYTERMINATEDMessage;
import com.sysfera.vishnu.api.tms.BATCHSCHEDULERERRORMessage;
import com.sysfera.vishnu.api.tms.CancelJobRequest;
import com.sysfera.vishnu.api.tms.CancelJobResponse;
import com.sysfera.vishnu.api.tms.DBCONNMessage;
import com.sysfera.vishnu.api.tms.DBERRMessage;
import com.sysfera.vishnu.api.tms.DIETMessage;
import com.sysfera.vishnu.api.tms.GetCompletedJobsOutputRequest;
import com.sysfera.vishnu.api.tms.GetCompletedJobsOutputResponse;
import com.sysfera.vishnu.api.tms.GetJobInfoResponse;
import com.sysfera.vishnu.api.tms.GetJobOutputRequest;
import com.sysfera.vishnu.api.tms.GetJobOutputResponse;
import com.sysfera.vishnu.api.tms.GetJobProgressRequest;
import com.sysfera.vishnu.api.tms.GetJobProgressResponse;
import com.sysfera.vishnu.api.tms.INVALIDPARAMMessage;
import com.sysfera.vishnu.api.tms.JOBISNOTTERMINATEDMessage;
import com.sysfera.vishnu.api.tms.ListJobsRequest;
import com.sysfera.vishnu.api.tms.ListJobsResponse;
import com.sysfera.vishnu.api.tms.ListQueuesRequest;
import com.sysfera.vishnu.api.tms.ListQueuesResponse;
import com.sysfera.vishnu.api.tms.PERMISSIONDENIEDMessage;
import com.sysfera.vishnu.api.tms.SESSIONKEYEXPIREDMessage;
import com.sysfera.vishnu.api.tms.SSHMessage;
import com.sysfera.vishnu.api.tms.SYSTEMMessage;
import com.sysfera.vishnu.api.tms.SubmitJobRequest;
import com.sysfera.vishnu.api.tms.SubmitJobResponse;
import com.sysfera.vishnu.api.tms.UNDEFINEDMessage;
import com.sysfera.vishnu.api.tms.UNKNOWNBATCHSCHEDULERMessage;
import com.sysfera.vishnu.api.tms.UNKNOWNMACHINEMessage;
import com.sysfera.vishnu.api.tms.VishnuTMSPortType;
import com.sysfera.vishnu.api.tms.VishnuTMSService;
import com.sysfera.vishnu.api.tms.GetJobInfoRequest;
import com.sysfera.vishnu.api.ums.ConnectRequest;
import com.sysfera.vishnu.api.ums.ConnectResponse;
import com.sysfera.vishnu.api.ums.SessionCloseType;
import com.sysfera.vishnu.api.ums.VishnuUMSPortType;
import com.sysfera.vishnu.api.ums.VishnuUMSService;

public class WSClientTMSTest {
	
	private static final String 	JBOSS_SERVER_NAME = "localhost";
	private static final Integer 	JBOSS_SERVER_PORT = 8080;
	private static final String		TEST_USER_LOGIN = "root";
	private static final String		TEST_USER_PASSWORD = "vishnu_user";
	
	private static final String 	MACHINEID = "machine_1";
	private static final String 	ACLOGIN	  = "vishnu";
	
	private static VishnuUMSPortType 	UMSPort;
	private static VishnuTMSPortType 	TMSPort;
	private static String				sessionKey;
	private static String				sessionId;
	private static String               jid;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("INIT TESTS");
		
		// Initialize web service interface
		UMSPort = getUMSPort("http://" + JBOSS_SERVER_NAME + ":" + JBOSS_SERVER_PORT + "/WSAPI/VishnuUMS?wsdl");
		TMSPort = getTMSPort("http://" + JBOSS_SERVER_NAME + ":" + JBOSS_SERVER_PORT + "/WSAPI/VishnuTMS?wsdl");
		
		// Initialize Vishnu session
		ConnectRequest request = new ConnectRequest();
		request.setUserId(TEST_USER_LOGIN);
		request.setPassword(TEST_USER_PASSWORD);
		request.setSessionInactivityDelay(new BigInteger("200"));
		System.out.println("Valeur du delai :"+request.getSessionInactivityDelay());
		request.setClosePolicy(SessionCloseType.valueOf(new String("CLOSE_ON_TIMEOUT")));
		ConnectResponse response = UMSPort.connect(request);
		sessionKey = response.getSessionKey();
		sessionId = response.getSessionId();
		System.out.println("SESSION KEY=" + sessionKey);
		System.out.println("SESSION ID=" + sessionId);
	}

	@Test
	public void testSubmitJob() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, INVALIDPARAMMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage, SSHMessage {
		SubmitJobRequest req = new SubmitJobRequest();
		req.setErrorPath("/tmp");
		req.setMachineId(MACHINEID);
		req.setOutputPath("/tmp");
		req.setSessionKey(sessionKey);
		req.setScriptFilePath("/home/keo/Bureau/launched");
		SubmitJobResponse resp = TMSPort.submitJob(req);
		jid = resp.getJobId();
		System.out.println("Job Id: "+resp.getJobId());
		System.out.println("Owner: "+resp.getOwner());
	}
	
	@Test
	public void testGetJobInfo() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage {
		GetJobInfoRequest req = new GetJobInfoRequest();
		req.setJobId(jid);
		req.setMachineId(MACHINEID);
		req.setSessionKey(sessionKey);
		GetJobInfoResponse resp = TMSPort.getJobInfo(req);
		System.out.println("job id: "+resp.getJobId());
		System.out.println("job name: "+resp.getJobName());
	}

	@Test
	public void testListJobs() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage {
		ListJobsRequest req = new ListJobsRequest();
		req.setSessionKey(sessionKey);
		req.setMachineId(MACHINEID);
		req.setJobId(jid);
		ListJobsResponse resp = TMSPort.listJobs(req);
		System.out.println("Job id: "+resp.getData().getJob().get(0).getJobId());
		System.out.println("Job name: "+resp.getData().getJob().get(0).getJobName());
		System.out.println("Job owner: "+resp.getData().getJob().get(0).getOwner());
	}


	@Test
	public void testListQueues() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage {
		ListQueuesRequest req = new ListQueuesRequest();
		req.setMachineId(MACHINEID);
		req.setSessionKey(sessionKey);
		ListQueuesResponse resp = TMSPort.listQueues(req);
		System.out.println("Queue1 name:"+resp.getData().getQueue().get(0).getName());
	}


	@Test
	public void testGetJobProgress() throws UNKNOWNMACHINEMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage {
		GetJobProgressRequest req = new GetJobProgressRequest();
		req.setMachineId(MACHINEID);
		req.setSessionKey(sessionKey);
		req.setJobId(jid);
		GetJobProgressResponse resp = TMSPort.getJobProgress(req);
	}

	@Test(expected=UNDEFINEDMessage.class)
	public void testGetJobOutput() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage, SSHMessage, JOBISNOTTERMINATEDMessage, ALREADYDOWNLOADEDMessage {
		GetJobOutputRequest req = new GetJobOutputRequest();
		req.setMachineId(MACHINEID);
		req.setSessionKey(sessionKey);
		GetJobOutputResponse resp = TMSPort.getJobOutput(req);
	}

	@Test
	public void testGetCompletedJobsOutput() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage, SSHMessage {
		GetCompletedJobsOutputRequest req = new GetCompletedJobsOutputRequest();
		req.setMachineId(MACHINEID);
		req.setSessionKey(sessionKey);
		GetCompletedJobsOutputResponse resp = TMSPort.getCompletedJobsOutput(req);
	}
	
	@Test
	public void testCancelJob() throws UNKNOWNBATCHSCHEDULERMessage, BATCHSCHEDULERERRORMessage, UNKNOWNMACHINEMessage, PERMISSIONDENIEDMessage, DBCONNMessage, DIETMessage, UNDEFINEDMessage, SESSIONKEYEXPIREDMessage, SYSTEMMessage, DBERRMessage, SSHMessage, ALREADYTERMINATEDMessage, ALREADYCANCELEDMessage {
		CancelJobRequest req = new CancelJobRequest();
		req.setJobId(jid);
		req.setMachineId(MACHINEID);
		req.setSessionKey(sessionKey);
		CancelJobResponse resp = TMSPort.cancelJob(req);
	}
	
	private static VishnuUMSPortType getUMSPort(String endpointURI) throws MalformedURLException   {

		URL wsdlURL = new URL(endpointURI);
		VishnuUMSService service = new VishnuUMSService(wsdlURL);
		return service.getVishnuUMSPort();
	}
	private static VishnuTMSPortType getTMSPort(String endpointURI) throws MalformedURLException   {

		URL wsdlURL = new URL(endpointURI);
		VishnuTMSService service = new VishnuTMSService(wsdlURL);
		return service.getVishnuTMSPort();
	}
}
