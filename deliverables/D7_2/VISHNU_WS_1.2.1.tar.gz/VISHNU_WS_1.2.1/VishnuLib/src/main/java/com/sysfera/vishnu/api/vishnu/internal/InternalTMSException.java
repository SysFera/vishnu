package com.sysfera.vishnu.api.vishnu.internal;

public class InternalTMSException extends Exception {
	public InternalTMSException(String s) {
		super(s);
	}
}
