@javax.xml.bind.annotation.XmlSchema(namespace = "urn:ResourceProxy")
package com.sysfera.vishnu.api.fms;
