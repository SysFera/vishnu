package com.sysfera.vishnu.api.vishnu.internal;

public class InternalUMSException extends Exception {
	public InternalUMSException(String s) {
		super(s);
	}
}
