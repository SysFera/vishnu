package com.sysfera.vishnu.api.vishnu.internal;

public class InternalIMSException extends Exception {
	public InternalIMSException(String s) {
		super(s);
	}
}
