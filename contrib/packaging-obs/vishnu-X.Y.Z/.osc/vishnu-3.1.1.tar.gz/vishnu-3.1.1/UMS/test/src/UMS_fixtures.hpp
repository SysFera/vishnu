/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * UMS_fixtures.hpp
 *
 * Author : bisnard
 */
#ifndef _UMS_FIXTURES_HPP_
#define _UMS_FIXTURES_HPP_



#include <boost/assign/list_inserter.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/assign/std/vector.hpp>
#include <boost/filesystem.hpp>
#include <boost/process/all.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/test/unit_test.hpp>
#include <boost/thread.hpp>
#include "FileParser.hpp"
#include "api_ums.hpp"

namespace ba = boost::assign;
namespace bf = boost::filesystem;
namespace bp = boost::process;
namespace bs = boost::system;


class UMSSeDFixture {

public:
  std::string m_test_ums_authen_type;
  std::string m_test_ums_root_vishnu_login;
  std::string m_test_ums_root_vishnu_pwd;
  std::string m_test_ums_admin_vishnu_login;
  std::string m_test_ums_admin_vishnu_pwd;
  std::string m_test_ums_user_vishnu_login;
  std::string m_test_ums_user_vishnu_pwd;
  std::string m_test_ums_user_vishnu_machineid;
  UMS_Data::Configuration mconf ;

  UMSSeDFixture() {
    BOOST_TEST_MESSAGE( "== Test setup [BEGIN]: Initializing client ==" );
    int argc = 2;
    char* argv[argc];
    const std::string vishnuClientTestConfigPath = getenv("VISHNU_CLIENT_TEST_CONFIG_FILE");
    BOOST_REQUIRE( vishnuClientTestConfigPath.size() !=0  );
    argv[0] = const_cast<char*>("./automTest");
    argv[1] = const_cast<char*>(vishnuClientTestConfigPath.c_str());

    if (vishnu::vishnuInitialize(argv[1], argc, argv)) {
      BOOST_TEST_MESSAGE( "Error in diet_initialize... (using config: "
      << vishnuClientTestConfigPath << ")" );
    }

    BOOST_TEST_MESSAGE( "== Test setup [END]: Initializing client ==" );

    BOOST_TEST_MESSAGE( "== Test setup [BEGIN]: LOADING SETUP ==" );
    std::string vishnuTestSetupPath = getenv("VISHNU_TEST_SETUP_FILE");
    BOOST_REQUIRE(vishnuTestSetupPath.size() !=0  );
    FileParser fileparser(vishnuTestSetupPath.c_str());
    std::map<std::string, std::string> setupConfig = fileparser.getConfiguration();

    m_test_ums_authen_type = setupConfig.find("TEST_UMS_AUTHEN_TYPE")->second ;
    m_test_ums_root_vishnu_login = setupConfig.find("TEST_ROOT_VISHNU_LOGIN")->second;
    m_test_ums_root_vishnu_pwd = setupConfig.find("TEST_ROOT_VISHNU_PWD")->second;
    m_test_ums_admin_vishnu_login = setupConfig.find("TEST_ADMIN_VISHNU_LOGIN")->second;
    m_test_ums_admin_vishnu_pwd = setupConfig.find("TEST_ADMIN_VISHNU_PWD")->second;
    m_test_ums_user_vishnu_login = setupConfig.find("TEST_USER_VISHNU_LOGIN")->second;
    m_test_ums_user_vishnu_pwd = setupConfig.find("TEST_USER_VISHNU_PWD")->second;
    m_test_ums_user_vishnu_machineid = setupConfig.find("TEST_VISHNU_MACHINEID1")->second;


    UMS_Data::ConnectOptions cop;
    UMS_Data::Session sess;
    vishnu::connect(m_test_ums_root_vishnu_login, m_test_ums_root_vishnu_pwd, sess, cop );
    vishnu::saveConfiguration(sess.getSessionKey(), mconf);


    BOOST_TEST_MESSAGE( "== Test setup [END]: LOADING SETUP ==");
  }


  ~UMSSeDFixture() {
    UMS_Data::ConnectOptions cop;
    UMS_Data::Session sess;
    vishnu::connect(m_test_ums_root_vishnu_login, m_test_ums_root_vishnu_pwd, sess, cop );
    vishnu::restoreConfiguration(sess.getSessionKey(), mconf.getFilePath());

    BOOST_TEST_MESSAGE( "== Test teardown [BEGIN]: UMSSeDFixture ==" );
    BOOST_TEST_MESSAGE( "== Test teardown [END]: UMSSeDFixture ==" );
  }
};



#endif  // _UMS_FIXTURES_HPP_
