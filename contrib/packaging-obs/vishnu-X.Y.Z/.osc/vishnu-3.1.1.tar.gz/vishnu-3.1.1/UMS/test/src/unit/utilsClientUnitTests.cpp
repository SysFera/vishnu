/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#include <boost/test/unit_test.hpp>
#include <string>
#include "utilsClient.hpp"
#include "UserException.hpp"
#include "UMSVishnuException.hpp"

BOOST_AUTO_TEST_SUITE( utilsClient_unit_tests )

BOOST_AUTO_TEST_CASE( test_checkIfTextIsEmpty_b )
{
  std::string empty = "";
  BOOST_REQUIRE_THROW(checkIfTextIsEmpty(empty,
                                         "empty string",
                                         ERRCODE_INVALID_PARAM),
                      UMSVishnuException);
}

BOOST_AUTO_TEST_CASE( test_checkIfTextIsEmpty_n )
{
  std::string nEmpty = "not empty";
  BOOST_REQUIRE_NO_THROW(checkIfTextIsEmpty(nEmpty,
                                            "empty string",
                                            ERRCODE_INVALID_PARAM));
}

BOOST_AUTO_TEST_CASE( test_checkEmail_n )
{
  std::string email1 = "test.toto@yopmail.com";
  std::string email2 = "test.toto.test@univ-somewhere.fr";
  std::string email3 = "contact@someplace.co";
  std::string email4 = "contact@localhost";
  std::string email5 = "contact@univ.co.uk";

  BOOST_REQUIRE_NO_THROW(checkEmail(email1));
  BOOST_REQUIRE_NO_THROW(checkEmail(email2));
  BOOST_REQUIRE_NO_THROW(checkEmail(email3));
  BOOST_REQUIRE_NO_THROW(checkEmail(email4));
  BOOST_REQUIRE_NO_THROW(checkEmail(email5));
}

BOOST_AUTO_TEST_CASE( test_checkEmail_b )
{
  std::string email1 = "test.toto@yopmail.com@somewhere.fr";
  BOOST_REQUIRE_THROW(checkEmail(email1), UMSVishnuException);
}

BOOST_AUTO_TEST_CASE( test_checkEmail_b2 )
{
  std::string email2 = "test.toto.test.univ-somewhere.fr";
  BOOST_REQUIRE_THROW(checkEmail(email2), UMSVishnuException);
}

BOOST_AUTO_TEST_CASE( test_checkEmail_b3 )
{
  std::string email3 = "http://contact@someplace.co";
  BOOST_REQUIRE_THROW(checkEmail(email3), UMSVishnuException);
}

BOOST_AUTO_TEST_CASE( test_checkEmail_b4 )
{
  std::string email3 = "john@aol...com";
  BOOST_REQUIRE_THROW(checkEmail(email3), UMSVishnuException);
}

BOOST_AUTO_TEST_SUITE_END()
