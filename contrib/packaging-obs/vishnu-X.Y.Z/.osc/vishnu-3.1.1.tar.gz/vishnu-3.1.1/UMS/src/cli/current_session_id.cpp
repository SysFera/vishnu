/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file current_session_id.cpp
 * This file defines the VISHNU get current session_id command
 * \author Ibrahima Cisse (ibrahima.cisse@sysfera.com)
 */


#include <unistd.h>                     // for getppid
#include <boost/smart_ptr/shared_ptr.hpp>  // for shared_ptr
#include <exception>                    // for exception
#include <iostream>                     // for operator<<, basic_ostream, etc
#include <string>                       // for allocator, operator+, etc

#include "GenericCli.hpp"               // for GenericCli
#include "Options.hpp"                  // for Options
#include "UserException.hpp"            // for ERRCODE_CLI_ERROR_RUNTIME
#include "VishnuException.hpp"          // for VishnuException, VISHNU_OK
#include "cliUtil.hpp"                  // for errorUsage, ::EXECERROR
#include "sessionUtils.hpp"             // for checkBadSessionKeyError, etc


using namespace std;
using namespace vishnu;


int main (int ac, char* av[]) {
  /**************** Describe options *************/
  try{
    boost::shared_ptr< Options> opt(new Options(av[0]));

    bool isEmpty;
    //To process list options
    GenericCli().processListOpt(opt, isEmpty, ac, av);

    // get the sessionId
    std::string sessionId=getLastSessionId(getppid());

    // Vishnu call
    if (false == sessionId.empty()){
      std::cout << "current sessionId: " <<  sessionId << "\n";
      return VISHNU_OK;
    }

    errorUsage(av[0],"cannot retrieve sessionId");
    return ERRCODE_CLI_ERROR_RUNTIME;

  } catch(VishnuException& e){// catch all Vishnu runtime error
    std::string  msg = e.getMsg()+" ["+e.getMsgComp()+"]";
    errorUsage(av[0], msg,EXECERROR);
    //check the bad session key
    if (checkBadSessionKeyError(e)){
      removeBadSessionKeyFromFile(getppid());
    }
    return e.getMsgI() ;
  } catch(std::exception& e){// catch all std runtime error
    errorUsage(av[0],e.what());
    return ERRCODE_CLI_ERROR_RUNTIME;
  }
}// end of main
