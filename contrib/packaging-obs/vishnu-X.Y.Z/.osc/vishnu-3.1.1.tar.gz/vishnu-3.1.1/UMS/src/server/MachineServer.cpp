/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
* \file MachineServer.cpp
* \brief This file implements the Class which manipulates VISHNU machine data on server side.
* \author Eugène PAMBA CAPO-CHICHI (eugene.capochichi@sysfera.com)
* \date 31/01/2011
*/

#include "MachineServer.hpp"
#include "DbFactory.hpp"
#include "RequestFactory.hpp"
#include "utilVishnu.hpp"
#include "utilServer.hpp"
#include <boost/format.hpp>


using namespace vishnu;

/**
* \brief Constructor
* \param machine The machine data structure
*/
MachineServer::MachineServer(UMS_Data::Machine*& machine):
  mmachine(machine)
{
  DbFactory factory;
  mdatabaseVishnu = factory.getDatabaseInstance();
}

/**
* \brief Constructor
* \param machine The machine data structure
* \param session The object which encapsulates session data
*/
MachineServer::MachineServer(UMS_Data::Machine*& machine, SessionServer& session):
  mmachine(machine), msessionServer(session)
{
  DbFactory factory;
  mdatabaseVishnu = factory.getDatabaseInstance();
}

/**
* \brief Function to add a new VISHNU machine
* \param vishnuId The identifier of the vishnu instance
* \return raises an exception on error
*/
int
MachineServer::add(int vishnuId) {
  std::string sqlUpdate = "update machine set ";
  std::string idMachineGenerated;

  UserServer userServer = UserServer(msessionServer);
  userServer.init();

  //if the user exists
  if (userServer.exist()) {
    //if the user is an admin
    if (userServer.isAdmin()) {
      //Generation of machineid
      idMachineGenerated = vishnu::getObjectId(vishnuId,
                                               "formatidmachine",
                                               MACHINE,
                                               mmachine->getName());

      //if the machine id is generated
      if (idMachineGenerated.size() != 0) {
        mmachine->setMachineId(idMachineGenerated);

        //if the machineId does not exist
        if (getAttribut("where machineid='"+mmachine->getMachineId()+"'","count(*)") == "1") {
          //To active the machine status
          mmachine->setStatus(vishnu::STATUS_ACTIVE);

          sqlUpdate+="name='"+mmachine->getName()+"',";
          sqlUpdate+="site='"+mmachine->getSite()+"',";
          sqlUpdate+="status="+convertToString(mmachine->getStatus());
          sqlUpdate+=" where machineid='"+mmachine->getMachineId()+"';";
          mdatabaseVishnu->process(sqlUpdate);

          mdatabaseVishnu->process("insert into description (machine_nummachineid, lang, description) values ("+getAttribut("where machineid='"+mmachine->getMachineId()+"'")+",'"+ mmachine->getLanguage()+"','"+mmachine->getMachineDescription()+"')");

        }//if the machine id is generated
        else {
          SystemException e (ERRCODE_SYSTEM, "There is a problem to parse the formatidmachine");
          throw e;
        }
      }//END if the formatidmachine is defined
      else {
        SystemException e (ERRCODE_SYSTEM, "The formatidmachine is not defined");
        throw e;
      }
    } //End if the user is an admin
    else {
      UMSVishnuException e (ERRCODE_NO_ADMIN);
      throw e;
    }
  }//End if the user exists
  else {
    UMSVishnuException e (ERRCODE_UNKNOWN_USER);
    throw e;
  }
  return 0;
} //END: add()

/**
* \brief Function to update a VISHNU machine
* \return raises an exception on error
*/
int
MachineServer::update() {

  std::string sqlCommand = "";



  UserServer userServer = UserServer(msessionServer);
  userServer.init();

  //if the user exists
  if (userServer.exist()) {
    //if the user is an admin
    if (userServer.isAdmin()) {

      //if the machine to update exists
      std::string sqlcond = (boost::format("WHERE machineid = '%1%'"
                                           " AND status != %2%")%mmachine->getMachineId() %vishnu::STATUS_DELETED).str();
      if (!getAttribut(sqlcond, "nummachineid").empty()) {

        //if a new machine name has been defined
        if (!mmachine->getName().empty()) {
          sqlCommand.append("UPDATE machine SET name='"+mmachine->getName()+"'\
                            where machineId='"+mmachine->getMachineId()+"';");
        }

        //if a new site has been defined
        if (!mmachine->getSite().empty()) {
          sqlCommand.append("UPDATE machine SET site='"+mmachine->getSite()+"'\
                            where machineId='"+mmachine->getMachineId()+"';");
        }

        //If a new status has been defined
        if (mmachine->getStatus() != vishnu::STATUS_UNDEFINED) {
          sqlCommand.append("UPDATE machine SET status="+convertToString(mmachine->getStatus())+
                            " where machineId='"+mmachine->getMachineId()+"';");
        }

        //if a new language has been defined
        if (!mmachine->getLanguage().empty()) {
          sqlCommand.append("UPDATE description SET lang='"+mmachine->getLanguage()+"'"
                            " where machine_nummachineid='"+getAttribut("where machineid='"+mmachine->getMachineId()+"'")+"';");
        }

        //if a new machine description has been defined
        if (!mmachine->getMachineDescription().empty()) {
          sqlCommand.append("UPDATE description SET description='"+mmachine->getMachineDescription()+"'"
                            " where machine_nummachineid='"+getAttribut("where machineid='"+mmachine->getMachineId()+"'")+"';");
        }

        //If there is a change
        if (!sqlCommand.empty()) {
          mdatabaseVishnu->process(sqlCommand.c_str());
        }

      } //End if the machine to update exists
      else {
        UMSVishnuException e (ERRCODE_UNKNOWN_MACHINE);
        throw e;
      }

    } //End if the user is an admin
    else {
      UMSVishnuException e (ERRCODE_NO_ADMIN);
      throw e;
    }
  }//End if the user exists
  else {
    UMSVishnuException e (ERRCODE_UNKNOWN_USER);
    throw e;
  }
  return 0;
} //END: update()

/**
* \brief Function to delete a VISHNU machine
* \return raises an exception on error
*/
int
MachineServer::deleteMachine() {
  mmachine->setStatus(vishnu::STATUS_DELETED);
  int ret = update();
  if (ret == 0){

    std::string req = mdatabaseVishnu->getRequest(VR_UPDATE_ACCOUNT_WITH_MACHINE);
    std::string sqlUpdate = (boost::format(req)
                            %vishnu::STATUS_DELETED
                            %mmachine->getMachineId()
                            ).str();

    return mdatabaseVishnu->process(sqlUpdate.c_str());
  }
  return ret;
} //END: deleteMachine()

/**
* \brief Destructor
*/
MachineServer::~MachineServer() {
}

/**
* \brief Function to get machine information
* \return  The user data structure
*/
UMS_Data::Machine*
MachineServer::getData() {
  return mmachine;
}

/**
* \brief Function to get machine information from the database vishnu
* \param condition The condition of the select request
* \param attrname the name of the attribut to get
* \return the value of the attribut or empty string if no results
*/

std::string
MachineServer::getAttribut(std::string condition, std::string attrname) {

  std::string sqlCommand("SELECT "+attrname+" FROM machine "+condition);
  boost::scoped_ptr<DatabaseResult> result(mdatabaseVishnu->getResult(sqlCommand.c_str()));
  return result->getFirstElement();
}

/**
* \brief Function to get the machine
* \return The name of the machine
*/
std::string
MachineServer::getMachineName() {

  std::string  machineName = getAttribut("where machineid='"+getData()->getMachineId()+"'", "name");

  return machineName;
}

/**
* \brief Function to check the machineId
* \return raises an exception
*/
void MachineServer::checkMachine() {

  std::string sqlcond ("");

  sqlcond = (boost::format("WHERE machineid = '%1%'"
                           " AND status != %2%")%mmachine->getMachineId() %vishnu::STATUS_DELETED).str();
  if (getAttribut(sqlcond, "nummachineid").empty()){
    throw UMSVishnuException(ERRCODE_UNKNOWN_MACHINE,
                             (boost::format("No machine with this id (%1%)")%mmachine->getMachineId()).str());
  }

  sqlcond = (boost::format("WHERE machineid = '%1%'"
                           " AND status = %2%")%mmachine->getMachineId() %vishnu::STATUS_LOCKED).str();
  if(!getAttribut(sqlcond, "nummachineid").empty()) {
    throw UMSVishnuException(ERRCODE_MACHINE_LOCKED);
  }
}
