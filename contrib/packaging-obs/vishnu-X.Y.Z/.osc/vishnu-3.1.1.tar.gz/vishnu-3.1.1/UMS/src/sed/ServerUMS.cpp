/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file ServerUMS.cpp
 * \brief This file presents the implementation of the UMS server.
 * \author Eugène PAMBA CAPO-CHICHI (eugene.capochichi@sysfera.com)
 * \date 31/01/2001
 */

#include "ServerUMS.hpp"
#include "internalApi.hpp"
#include "Authenticator.hpp"
#include "AuthenticatorFactory.hpp"
#include "UMSServices.hpp"

//{{RELAX<MISRA_0_1_3> Because these variables are used in this class
Database *ServerUMS::mdatabaseVishnu = NULL;
ServerUMS *ServerUMS::minstance = NULL;
UMSMapper *ServerUMS::mmapper = NULL;
TMSMapper *ServerUMS::mmapperTMS = NULL;
FMSMapper *ServerUMS::mmapperFMS = NULL;
IMSMapper *ServerUMS::mmapperIMS = NULL;
Authenticator *ServerUMS::mauthenticator = NULL;

//}}RELAX<MISRA_0_1_3>

using namespace vishnu;


/**
 * \brief To get the unique instance of the server
 */
ServerUMS*
ServerUMS::getInstance() {
  if (minstance == NULL) {
    minstance = new ServerUMS();
  }
  return minstance;
}

/**
 * \brief To get the vishnuId
 * \return the path of the configuration file
 */
int
ServerUMS::getVishnuId() const {
  return mvishnuId;
}

/**
 * \brief To get the path to the sendmail script
 * \return the path of the configuration file
 */
std::string
ServerUMS::getSendmailScriptPath() const {
  return msendmailScriptPath;
}

/**
 * \brief Constructor (private)
 */
ServerUMS::ServerUMS() {
}

/**
 * \brief To initialize the UMS server with individual parameters
 * \param vishnuId The id of the vishnu configuration registered in the database
 * \param dbConfig  The configuration of the database
 * \param sendmailScriptPath The path to the script for sending emails
 * \param authenticatorConfig The configuration of the authenticator
 * \return an error code (0 if success and 1 if an error occurs)
 */
int
ServerUMS::init(int vishnuId,
                DbConfiguration dbConfig,
                std::string sendmailScriptPath,
                AuthenticatorConfiguration authenticatorConfig) {

  msendmailScriptPath = sendmailScriptPath;

  DbFactory factory;
  AuthenticatorFactory authfactory;

  try {
    mdatabaseVishnu = factory.createDatabaseInstance(dbConfig);
    mauthenticator = authfactory.createAuthenticatorInstance(authenticatorConfig);

    mvishnuId = vishnuId;

    std::string sqlCommand("SELECT * FROM vishnu where vishnuid="+convertToString(mvishnuId));

    /*connection to the database*/
    mdatabaseVishnu->connect();
    mmapperTMS = new TMSMapper(MapperRegistry::getInstance(), TMSMAPPERNAME);
    mmapperTMS->registerMapper();
    mmapperIMS = new IMSMapper(MapperRegistry::getInstance(), IMSMAPPERNAME);
    mmapperIMS->registerMapper();
    mmapperFMS = new FMSMapper(MapperRegistry::getInstance(), FMSMAPPERNAME);
    mmapperFMS->registerMapper();
    mmapper = new UMSMapper(MapperRegistry::getInstance(), UMSMAPPERNAME);
    mmapper->registerMapper();

    /* Checking of vishnuid on the database */
    boost::scoped_ptr<DatabaseResult> result(mdatabaseVishnu->getResult(sqlCommand.c_str()));
    if (result->getResults().size() == 0) {
      SystemException e(ERRCODE_DBERR, "The vishnuid is unrecognized");
      throw e;
    }

  } catch (VishnuException& e) {
      std::cout << e.what() << "\n";
      exit(0);
  }

// initialization of the service table
  initMap();

  return 0;
}

/**
 * \brief Destructor, raises an exception on error
 */
ServerUMS::~ServerUMS() {
  if (mmapper != NULL) {
    delete mmapper;
  }
  if (mdatabaseVishnu != NULL) {
    delete mdatabaseVishnu;
  }
  if (mauthenticator != NULL) {
    delete mauthenticator;
  }
}

void
ServerUMS::initMap() {

  int (*functionPtr)(diet_profile_t*);

  functionPtr = solveSessionConnect;
  mcb[SERVICES_UMS[SESSIONCONNECT]] = functionPtr;
  functionPtr = solveSessionReconnect;
  mcb[SERVICES_UMS[SESSIONRECONNECT]] = functionPtr;
  functionPtr = solveSessionClose;
  mcb[SERVICES_UMS[SESSIONCLOSE]] = functionPtr;
  functionPtr = solveUserCreate;
  mcb[SERVICES_UMS[USERCREATE]] = functionPtr;
  functionPtr = solveUserUpdate;
  mcb[SERVICES_UMS[USERUPDATE]] = functionPtr;
  functionPtr = solveUserDelete;
  mcb[SERVICES_UMS[USERDELETE]] = functionPtr;
  functionPtr = solveUserPasswordChange;
  mcb[SERVICES_UMS[USERPASSWORDCHANGE]] = functionPtr;
  functionPtr = solveUserPasswordReset;
  mcb[SERVICES_UMS[USERPASSWORDRESET]] = functionPtr;
  functionPtr = solveMachineCreate;
  mcb[SERVICES_UMS[MACHINECREATE]] = functionPtr;
  functionPtr = solveMachineUpdate;
  mcb[SERVICES_UMS[MACHINEUPDATE]] = functionPtr;
  functionPtr = solveMachineDelete;
  mcb[SERVICES_UMS[MACHINEDELETE]] = functionPtr;
  functionPtr = solveLocalAccountCreate;
  mcb[SERVICES_UMS[LOCALACCOUNTCREATE]] = functionPtr;
  functionPtr = solveLocalAccountUpdate;
  mcb[SERVICES_UMS[LOCALACCOUNTUPDATE]] = functionPtr;
  functionPtr = solveLocalAccountDelete;
  mcb[SERVICES_UMS[LOCALACCOUNTDELETE]] = functionPtr;
  functionPtr = solveConfigurationSave;
  mcb[SERVICES_UMS[CONFIGURATIONSAVE]] = functionPtr;
  functionPtr = solveConfigurationRestore;
  mcb[SERVICES_UMS[CONFIGURATIONRESTORE]] = functionPtr;
  functionPtr = solveOptionValueSet;
  mcb[SERVICES_UMS[OPTIONVALUESET]] = functionPtr;
  functionPtr = solveOptionValueSetDefault;
  mcb[SERVICES_UMS[OPTIONVALUESETDEFAULT]] = functionPtr;
  functionPtr = solveListSessions;
  mcb[SERVICES_UMS[SESSIONLIST]] = functionPtr;
  functionPtr = solveListLocalAccount;
  mcb[SERVICES_UMS[LOCALACCOUNTLIST]] = functionPtr;
  functionPtr = solveListMachines;
  mcb[SERVICES_UMS[MACHINELIST]] = functionPtr;
  functionPtr = solveListHistoryCmd;
  mcb[SERVICES_UMS[COMMANDLIST]] = functionPtr;
  functionPtr = solveListOptions;
  mcb[SERVICES_UMS[OPTIONVALUELIST]] = functionPtr;
  functionPtr = solveListUsers;
  mcb[SERVICES_UMS[USERLIST]] = functionPtr;
  functionPtr = solveRestore;
  mcb[SERVICES_UMS[RESTORE]] = functionPtr;
  functionPtr = solveSystemAuthCreate;
  mcb[SERVICES_UMS[AUTHSYSTEMCREATE]] = functionPtr;
  functionPtr = solveSystemAuthUpdate;
  mcb[SERVICES_UMS[AUTHSYSTEMUPDATE]] = functionPtr;
  functionPtr = solveSystemAuthDelete;
  mcb[SERVICES_UMS[AUTHSYSTEMDELETE]] = functionPtr;
  functionPtr = solveSystemAuthList;
  mcb[SERVICES_UMS[AUTHSYSTEMLIST]] = functionPtr;
  functionPtr = solveAccountAuthCreate;
  mcb[SERVICES_UMS[AUTHACCOUNTCREATE]] = functionPtr;
  functionPtr = solveAccountAuthUpdate;
  mcb[SERVICES_UMS[AUTHACCOUNTUPDATE]] = functionPtr;
  functionPtr = solveAccountAuthDelete;
  mcb[SERVICES_UMS[AUTHACCOUNTDELETE]] = functionPtr;
  functionPtr = solveAccountAuthList;
  mcb[SERVICES_UMS[AUTHACCOUNTLIST]] = functionPtr;
  mcb[SERVICES_UMS[INT_DEFINEUSERIDENTIFIER]] = solveSetUID;
  mcb[SERVICES_UMS[INT_DEFINEJOBIDENTIFIER]] = solveSetJID;
  mcb[SERVICES_UMS[INT_DEFINETRANSFERIDENTIFIER]] = solveSetTID;
  mcb[SERVICES_UMS[INT_DEFINEMACHINEIDENTIFIER]] = solveSetMID;
  mcb[SERVICES_UMS[INT_DEFINEAUTHIDENTIFIER]] = solveSetAID;
  mcb[SERVICES_UMS[INT_DEFINEWORKIDENTIFIER]] = solveSetWID;
}
