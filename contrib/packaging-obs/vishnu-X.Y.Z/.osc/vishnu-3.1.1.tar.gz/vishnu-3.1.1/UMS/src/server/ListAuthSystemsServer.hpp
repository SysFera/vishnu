/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file ListAuthSystemsServer.hpp
 * \brief This file contains the VISHNU QueryServer class.
 * \author Eugène PAMBA CAPO-CHICHI (eugene.capochichi@sysfera.com)
 * \date February 2012
 */
#ifndef _LIST_AUTH_SYSTEMS_SERVER_
#define _LIST_AUTH_SYSTEMS_SERVER_

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include "boost/date_time/posix_time/posix_time.hpp"

#include "SessionServer.hpp"
#include "QueryServer.hpp"

#include "ListAuthSystems.hpp"
#include "ListAuthSysOptions.hpp"

/**
 * \class ListAuthSystemsServer
 * \brief ListAuthSystemsServer class implementation
 */
class ListAuthSystemsServer: public QueryServer<UMS_Data::ListAuthSysOptions, UMS_Data::ListAuthSystems>
{

public:

  /**
   * \param session The object which encapsulates the session information (ex: identifier of the session)
   * \brief Constructor, raises an exception on error
   */
  ListAuthSystemsServer(const SessionServer& session):
    QueryServer<UMS_Data::ListAuthSysOptions, UMS_Data::ListAuthSystems>(session), mcommandName("vishnu_list_auth_systems")
  {

  }
  /**
   * \param params The object which encapsulates the information of ListAuthSystemsServer  options
   * \param session The object which encapsulates the session information (ex: identifier of the session)
   * \brief Constructor, raises an exception on error
   */
  ListAuthSystemsServer(UMS_Data::ListAuthSysOptions_ptr params, const SessionServer& session):
    QueryServer<UMS_Data::ListAuthSysOptions, UMS_Data::ListAuthSystems>(params,session), mcommandName("vishnu_list_auth_systems")
  {

  }

  /**
   * \brief Function to treat the ListAuthSystemsServer options
   * \param userServer the object which encapsulates user information
   * \param options The object which encapsulates the information of ListAuthSystemsServer  options
   * \param sqlRequest the sql data base request
   * \return raises an exception on error
   */
  void
  processOptions(UserServer userServer, const UMS_Data::ListAuthSysOptions_ptr& options, std::string& sqlRequest) {


    mfullInfo = options->isListFullInfo();
    //If the full option is defined, the user must be an admin
    if (mfullInfo) {
      if(!userServer.isAdmin()) {
        UMSVishnuException e (ERRCODE_NO_ADMIN);
        throw e;
      }
    }

    if (options != NULL) {
      std::string  userId = options->getUserId();
      if(userId.size()!=0) {
        //If the user is an admin
        if(userServer.isAdmin()) {
          checkUserId(userId);
          sqlRequest.append(" and authsystemid IN (SELECT authsystemid from authsystem, users,"
                            "authaccount where userid='"+userId+"'"
                            "and authaccount.authsystem_authsystemid=authsystem.numauthsystemid and authaccount.users_numuserid=users.numuserid)"
                            );
        }//End If the user is an admin
        else {
          UMSVishnuException e (ERRCODE_NO_ADMIN);
          throw e;
        }
      }

      std::string  authSystemId = options->getAuthSystemId();
      if(authSystemId.size()!=0) {
        //To check if the authSystem identifier is correct
        checkAuthSystemId(authSystemId);
        addOptionRequest("authsystemid", authSystemId, sqlRequest);
      }

      //If the option for listing all authSystem has not defined
      if (!options->isListAllAuthSystems()) {
        //If the option userId has not
        if ((userId.size() == 0) && (authSystemId.size() == 0)) {
          sqlRequest.append(" and authsystemid IN (SELECT authsystemid from authsystem, users,"
                            "authaccount where userid='"+userServer.getData().getUserId()+"'"
                            "and authaccount.authsystem_authsystemid=authsystem.numauthsystemid and authaccount.users_numuserid=users.numuserid)"
                            );
        }
      }
    }
    else {
      sqlRequest.append(" and authsystemid IN (SELECT authsystemid from authsystem, users, "
                        "authaccount where userid='"+userServer.getData().getUserId()+"'"
                        "and authaccount.authsystem_authsystemid=authsystem.numauthsystemid and authaccount.users_numuserid=users.numuserid)"
                        );
    }
  }

  /**
  * \brief Function to list machines information
  * \return The pointer to the UMS_Data::ListAuthSystems containing users information
  * \return raises an exception on error
  */
  UMS_Data::ListAuthSystems* list() {

    std::string sql = (boost::format("SELECT authsystemid, name, uri, authlogin, authpassword,"
                                     "       userpwdencryption, authtype, authsystem.status, ldapbase "
                                     " FROM  authsystem, ldapauthsystem"
                                     " WHERE ldapauthsystem.authsystem_authsystemid = authsystem.numauthsystemid"
                                     "  AND authsystem.status!=%1%")%vishnu::STATUS_DELETED).str();
    std::vector<std::string>::iterator ii;
    std::vector<std::string> results;
    UMS_Data::UMS_DataFactory_ptr ecoreFactory = UMS_Data::UMS_DataFactory::_instance();
    mlistObject = ecoreFactory->createListAuthSystems();

    //Creation of the object user
    UserServer userServer = UserServer(msessionServer);
    userServer.init();
    //if the user exists
    if (userServer.exist()) {

      processOptions(userServer, mparameters, sql);
      sql.append(" order by authsystemid");
      //To get the list of authSystems from the database
      boost::scoped_ptr<DatabaseResult> ListofAuthSystems (mdatabaseVishnu->getResult(sql.c_str()));
      if (ListofAuthSystems->getNbTuples() != 0){
        for (size_t i = 0; i < ListofAuthSystems->getNbTuples(); ++i) {
          results.clear();
          results = ListofAuthSystems->get(i);
          ii = results.begin();
          UMS_Data::AuthSystem_ptr authSystem = ecoreFactory->createAuthSystem();
          authSystem->setAuthSystemId(*ii);
          authSystem->setName(*(++ii));
          authSystem->setURI(*(++ii));
          std::string authLogin(*(++ii));
          std::string authPassword(*(++ii));
          int userPasswordEncryption(vishnu::convertToInt(*(++ii)));
          int type(vishnu::convertToInt(*(++ii)));
          if (mfullInfo) {
            authSystem->setAuthLogin(authLogin);
            authSystem->setAuthPassword(authPassword);
            authSystem->setUserPasswordEncryption(userPasswordEncryption);
            authSystem->setType(type);
          }
          authSystem->setStatus(vishnu::convertToInt(*(++ii)));
          authSystem->setLdapBase(*(++ii));
          mlistObject->getAuthSystems().push_back(authSystem);
        }
      }
    }
    else {
      UMSVishnuException e (ERRCODE_UNKNOWN_USER);
      throw e;
    }
    return mlistObject;


  }

  /**
   * \brief Function to get the name of the ListAuthSystemsServer command line
   * \return The the name of the ListAuthSystemsServer command line
   */
  std::string
  getCommandName()
  {
    return mcommandName;
  }

  /**
   * \brief Destructor, raises an exception on error
   */
  ~ListAuthSystemsServer() { }

private:

  /////////////////////////////////
  // Attributes
  /////////////////////////////////

  /**
  * \brief The name of the ListMachinesServer command line
  */
  std::string mcommandName;
  /**
  * \brief An option to have full information
  */
  bool mfullInfo;
};

#endif
