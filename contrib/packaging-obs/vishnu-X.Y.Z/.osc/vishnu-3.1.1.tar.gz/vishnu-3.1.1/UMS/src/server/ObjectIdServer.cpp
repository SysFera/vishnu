/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#include "ObjectIdServer.hpp"

#include <string>
#include <boost/algorithm/string.hpp>

#include "DbFactory.hpp"

ObjectIdServer::ObjectIdServer(const UserServer session):msession(session) {
  DbFactory factory;
  mdatabase = factory.getDatabaseInstance();
  mvishnuId  = 1;
}

ObjectIdServer::~ObjectIdServer() {
}


/**
 * \brief To set the format of an entry
 */
void
ObjectIdServer::setformat(std::string fmt, std::string entry){
  if (!msession.isAdmin()){
    throw UMSVishnuException(ERRCODE_NO_ADMIN, "define "+entry+ "id  format is an admin function. A user cannot call it");
  }
  boost::trim(entry);
  if (fmt.find_first_of('@')!=std::string::npos) {
    throw UserException(10, "Invalid format, it cannot contain the @ character. ");
  }
  std::string request = "update  vishnu set  formatid"+entry+" ='"+fmt+"' where  vishnuid ='";
  request += vishnu::convertToString(mvishnuId);
  request += "'";
  try{
    mdatabase->process(request.c_str());
  }catch(SystemException& e){
    e.appendMsgComp("Failed to set the "+entry+" format to "+fmt);
    throw(e);
  }
}



bool
ObjectIdServer::containCpt(std::string fmt) {
  return (fmt.find("$CPT")!=std::string::npos);
}
