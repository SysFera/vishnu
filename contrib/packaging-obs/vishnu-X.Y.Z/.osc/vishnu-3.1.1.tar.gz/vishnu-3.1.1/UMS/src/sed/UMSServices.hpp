/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file UMSServices.hpp
 * \brief This file lists the services provided by UMS servers.
 * \author Benjamin Depardon (benjamin.depardon@sysfera.com)
 * \date 21/02/2013
 */

#ifndef _UMSSERVICES_HPP_
#define _UMSSERVICES_HPP_


/**
 * \brief UMS services enumeration
 */
typedef enum {
  SESSIONCONNECT = 0,
  SESSIONRECONNECT,
  SESSIONCLOSE,
  USERCREATE,
  USERUPDATE,
  USERDELETE,
  USERPASSWORDCHANGE,
  USERPASSWORDRESET,
  MACHINECREATE,
  MACHINEUPDATE,
  MACHINEDELETE,
  LOCALACCOUNTCREATE,
  LOCALACCOUNTUPDATE,
  LOCALACCOUNTDELETE,
  CONFIGURATIONSAVE,
  CONFIGURATIONRESTORE,
  OPTIONVALUESET,
  OPTIONVALUESETDEFAULT,
  SESSIONLIST,
  LOCALACCOUNTLIST,
  MACHINELIST,
  COMMANDLIST,
  OPTIONVALUELIST,
  USERLIST,
  RESTORE,
  AUTHSYSTEMCREATE,
  AUTHSYSTEMUPDATE,
  AUTHSYSTEMDELETE,
  AUTHSYSTEMLIST,
  AUTHACCOUNTCREATE,
  AUTHACCOUNTUPDATE,
  AUTHACCOUNTDELETE,
  AUTHACCOUNTLIST,
  INT_DEFINEUSERIDENTIFIER,
  INT_DEFINEJOBIDENTIFIER,
  INT_DEFINETRANSFERIDENTIFIER,
  INT_DEFINEMACHINEIDENTIFIER,
  INT_DEFINEAUTHIDENTIFIER,
  INT_DEFINEWORKIDENTIFIER,
  NB_SRV_UMS  // MUST always be the last
} ums_service_t;

static const char* SERVICES_UMS[NB_SRV_UMS] = {
  "sessionConnect",  // 0
  "sessionReconnect",  // 1
  "sessionClose",  // 2
  "userCreate",  // 3
  "userUpdate",  // 4
  "userDelete",  // 5
  "userPasswordChange",  // 6
  "userPasswordReset",  // 7
  "machineCreate",  // 8
  "machineUpdate",  // 9
  "machineDelete",  // 10
  "localAccountCreate",  // 11
  "localAccountUpdate",  // 12
  "localAccountDelete",  // 13
  "configurationSave",  // 14
  "configurationRestore",  // 15
  "optionValueSet",  // 16
  "optionValueSetDefault",  // 17
  "sessionList",  // 18
  "localAccountList",  // 19
  "machineList",  // 20
  "commandList",  // 21
  "optionValueList",  // 22
  "userList",  // 23
  "restore",  // 24
  "authSystemCreate",  // 25
  "authSystemUpdate",  // 26
  "authSystemDelete",  // 27
  "authSystemList",  // 28
  "authAccountCreate",  // 29
  "authAccountUpdate",  // 30
  "authAccountDelete",  // 31
  "authAccountList",  // 32
  "int_defineUserIdentifier", // 33
  "int_defineJobIdentifier", // 34
  "int_defineTransferIdentifier", // 35
  "int_defineMachineIdentifier", // 36
  "int_defineAuthIdentifier", // 37
  "int_defineWorkIdentifier" // 38
};

#endif  // _UMSSERVICES_HPP_
