/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#include <boost/test/unit_test.hpp>
#include <iostream>
#include <vector>
#include "Server.hpp"

std::string mname;
std::vector<std::string> mservices;
std::string muri;

class ZMQServerFixture {
public:
  ZMQServerFixture(){
    mname = "pierre";
    muri = "tcp://*:5555";
    mservices.clear();
    mservices.push_back("loup");
    mservices.push_back("belette");
  }

  ~ZMQServerFixture(){
    mservices.clear();
  }
};


BOOST_FIXTURE_TEST_SUITE( ZMQserver_unit_tests, ZMQServerFixture )


BOOST_AUTO_TEST_CASE( test_fromStr_n )
{
// Test the server class
  std::string res = mname + "$$$" + muri + "$$$" + mservices.at(0) + "$$$" +
    mservices.at(1) + "$$$";
  boost::shared_ptr<Server> s = Server::fromString(res);

  BOOST_REQUIRE_EQUAL(s->getName(), mname);
  BOOST_REQUIRE_EQUAL(s->getURI(), muri);
  BOOST_REQUIRE_EQUAL((s->getServices()).size(), mservices.size());
}


BOOST_AUTO_TEST_CASE( test_toStr_n )
{
// Test the server class
  Server s(mname, mservices, muri);
  std::string res = mname + "$$$" + muri + "$$$" + mservices.at(0) + "$$$" +
    mservices.at(1) + "$$$";

  BOOST_REQUIRE_EQUAL(res, s.toString());
}

BOOST_AUTO_TEST_CASE( test_add_n_serv )
{
// Test the server class
  std::string str = "lapin";
  Server s(mname, mservices, muri);
  s.add(str);

  BOOST_REQUIRE_EQUAL(s.getServices().size(), 3);
  BOOST_REQUIRE(s.hasService(str));
}

BOOST_AUTO_TEST_CASE( test_add_twice_n_serv )
{
// Test the server class
  std::string str = "lapin";
  Server s(mname, mservices, muri);
  s.add(str);
  s.add(str);

  BOOST_REQUIRE_EQUAL(s.getServices().size(), 3);
  BOOST_REQUIRE(s.hasService(str));
}

BOOST_AUTO_TEST_CASE( test_remove_n_serv )
{
// Test the server class
  std::string rem = mservices.at(1);
  Server s(mname, mservices, muri);
  s.remove(rem);

  BOOST_REQUIRE_EQUAL(s.getServices().size(), 1);
  BOOST_REQUIRE(!s.hasService(rem));
}

BOOST_AUTO_TEST_CASE( test_remove_b_invalid )
{
// Test the server class
  std::string rem = "bad";
  int size;
  int res;
  Server s(mname, mservices, muri);
  size = s.getServices().size();
  s.remove(rem);
  res = s.getServices().size();

  BOOST_REQUIRE_EQUAL(res, size);
}

BOOST_AUTO_TEST_CASE( test_haz_n_ser )
{
// Test the server class
  Server s(mname, mservices, muri);

  BOOST_REQUIRE(s.hasService(mservices.at(0)));
  BOOST_REQUIRE(s.hasService(mservices.at(1)));
}

BOOST_AUTO_TEST_CASE( test_haz_b )
{
// Test the server class
  Server s(mname, mservices, muri);

  BOOST_REQUIRE(!s.hasService("bad"));
}

BOOST_AUTO_TEST_CASE( test_getname_n )
{
// Test the server class
  Server s(mname, mservices, muri);

  BOOST_REQUIRE_EQUAL(s.getURI(), muri);
}

BOOST_AUTO_TEST_CASE( test_getserv_n )
{
// Test the server class
  Server s(mname, mservices, muri);

  BOOST_REQUIRE_EQUAL(s.getServices().at(0), mservices.at(0));
  BOOST_REQUIRE_EQUAL(s.getServices().at(1), mservices.at(1));
}

BOOST_AUTO_TEST_CASE( test_geturi_n )
{
// Test the server class
  Server s(mname, mservices, muri);

  BOOST_REQUIRE_EQUAL(s.getURI(), muri);
}


BOOST_AUTO_TEST_SUITE_END()
