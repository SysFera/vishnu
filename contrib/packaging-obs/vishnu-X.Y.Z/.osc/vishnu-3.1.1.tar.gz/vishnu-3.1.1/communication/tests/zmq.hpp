/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#include <iostream>
#include <cstdlib>
#include <cstring>

#ifndef TOTO
#define TOTO
// Mock file for zmq items

#define ZMQ_LINGER 1
#define ZMQ_POLLIN 1
#define ZMQ_REQ 1
#define ZMQ_REP 1
#define ZMQ_ROUTER 1
#define ZMQ_DEALER 1
#define ZMQ_QUEUE 1

bool
setsockopt(int p1, int* p2, int p3);


namespace zmq {

typedef int context_t;

class error_t : public std::exception {
public:
  error_t(){}

  int
  num() const {
    return 0;
  }
};


class message_t{
public:
  message_t() : mbuff("ok") {
    msize = mbuff.length();
  }

  message_t(const std::string& p1) : mbuff("ok") {
    msize = mbuff.length();
  }

  message_t(int p1) : mbuff("ok") {
    msize = mbuff.length();
  }

  void*
  data(){
    char* s = static_cast<char *>(malloc(sizeof(char) * mbuff.length()));
    memcpy(s, mbuff.c_str(), mbuff.length() + 1);
    return s;
  }

  int
  size(){
    return msize;
  }

private :
  int msize;
  std::string mbuff;
};


class socket_t{
public:
  socket_t(context_t p1, int p2){
  }
  bool
  send(message_t msg, int flag){
    if (maddr.compare("bad")==0){
      return false;
    }
    return true;
  }

  bool
  send(message_t& msg){
    if (maddr.compare("bad")==0){
      return false;
    }
    return true;
  }

  bool
  recv(message_t* msg){
    if (maddr.compare("bad")==0){
      return false;
    }
    return true;
  }

  bool
  recv(message_t* msg, int flag){
    if (maddr.compare("bad")==0){
      return false;
    }
    return true;
  }

  void
  connect(const char* addr){
    maddr = std::string(addr);
  }

  void
  bind(const char* ){
  }
private :
  std::string maddr;
};


typedef struct pollitem_t{
public:
  zmq::socket_t s;
  int revents;
  int p1;
  int p2;
}pollitem_t;

void
poll(pollitem_t* p1, int, int);


void
device(int p1, socket_t p2, socket_t p3);

}



#endif
