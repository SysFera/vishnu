/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#ifndef __SED__H__
#define __SED__H__

#include "DIET_client.h"
#include "sslhelpers.hpp"
#include <map>
#include <string>
#include <vector>
#include <boost/function.hpp>

#define UNKNOWN_SERVICE 1;
#define INTERNAL_ERROR 2;

typedef boost::function1<int, diet_profile_t*> CallbackFn;
typedef std::map<std::string, CallbackFn> CallbackMap;
;
/**
 * \class SeD
 * \brief base class to Server*MS classes
 */
class SeD {
public:
  /**
   * \brief Constructor
   */
  SeD();

  /**
   * \brief To call a function upon receiving a request
   * \param prof The profile of the service
   * \return the error code of the function
   */
  virtual int
  call(diet_profile_t* prof);

  /**
   * \brief To get the services offered by the server
   * \return the services offered by the server
   */
  virtual std::vector<std::string>
  getServices();

protected:
  /**
   * \brief map with function ptr for callback
   */
  CallbackMap mcb;
};

/**
 * @brief ZMQServerStart
 * @param server
 * @param uri
 * @param useSsl
 * @param cafile
 * @return
 */
int
ZMQServerStart(boost::shared_ptr<SeD> server,
               const std::string& uri,
               bool useSsl,
               const std::string& cafile);


#endif // __SED__H__
