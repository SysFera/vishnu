/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file handlers.hpp
 * \brief This file contains the definition of the handlers used for the communication layers
 * \author Haikel Guemar (haikel.guemar@sysfera.com)
 * \date January 2013
 */
#ifndef _HANDLERS_HPP_
#define _HANDLERS_HPP_

#include "zhelpers.hpp"
#include "AnnuaryWorker.hpp"


/**
 * \struct InternalEndPoint
 * \brief Get the endpoint for the subscribers
 */
template<typename T>
struct InternalEndpoint {
  /**
   * \brief Return the value of the endpoint
   */
  static std::string value() { return ""; };
};

template<>
struct InternalEndpoint<SubscriptionWorker> {
  /**
   * \brief Return the value of the endpoint
   */
  static std::string value() { return "inproc://vishnuSubcriberWorker"; };
};

template<>
struct InternalEndpoint<ServiceWorker> {
  /**
   * \brief Return the value of the endpoint
   */
  static std::string value() { return "inproc://vishnuServiceWorker"; };
};


/**
 * \class Handler
 * \brief generic handler parameterized by its Worker class
 */
template<typename Worker>
class Handler {
public:

  /**
   * \brief Constructor
   * \param uri the uri for the handler
   * \param ann the annuary
   * \param nbThread the number of threads to use
   */
  Handler(const std::string& uri,
          boost::shared_ptr<Annuary> ann,
          int nbThread,
          bool usessl,
          const std::string& certCaFile)
    : muri(uri), mann(ann), nbThread(nbThread), useSsl(usessl), cafile(certCaFile) {}

  /**
   * \brief To run the handler
   */
  void
  run() {
    serverWorkerSockets<Worker,
        boost::shared_ptr<Annuary> >(muri,
                                     InternalEndpoint<Worker>::value(),
                                     nbThread,
                                     mann,
                                     useSsl,
                                     cafile);
  }

private:
  /**
   * \brief The uri
   */
  const std::string muri;

  /**
   * \brief The annuary
   */
  boost::shared_ptr<Annuary> mann;

  /**
   * \brief The number of threads to use
   */
  int nbThread;

  /**
   * \brief  path to the CA file
  */
  bool useSsl;

  /**
   * \brief  path to the CA file
  */
  std::string cafile;
};

/**
 * \brief Handler for the clients
 */
typedef Handler<ServiceWorker> Handler4Clients;
/**
 * \brief Handler for the servers
 */
typedef Handler<SubscriptionWorker> Handler4Servers;

#endif /* _HANDLERS_HPP_ */
