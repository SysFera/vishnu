/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file communication/utils.hpp
 * \brief this file contains a declaration of helper functions used by the communication layer
 * \authors Kevin Coulomb (kevin.coulomb@sysfera.com)
 */

#ifndef _UTILS_HPP_
#define _UTILS_HPP_

#include <functional>
#include <queue>
#include <vector>
#include <boost/thread.hpp>
#include <boost/version.hpp>

/**
 * \brief Definition of a task
 */
typedef boost::function0<void> Task;

namespace threadsafe {

/**
 * @class queue
 * @brief simple thread-safe queue
 */
template<typename T>
class queue {
public:
  queue() {};

  void
  push(T value) {
    boost::lock_guard<boost::mutex> lock(mutex_);
    {
      data_.push(value);
    }

    cond_.notify_one();
  }

  bool
  try_pop(T& value) {
    boost::lock_guard<boost::mutex> lock(mutex_);
    if (data_.empty()) {
      return false;
    }
    value = data_.front();
    data_.pop();
  }

  void
  wait_and_pop(T& value) {
    // we use unique_lock since we'll use it with conditions
    boost::unique_lock<boost::mutex> lock(mutex_);
    while (data_.empty()) {
       cond_.wait(lock);
    }
    value = data_.front();
    data_.pop();
  }

  bool
  empty() const {
    boost::lock_guard<boost::mutex> lock(mutex_);
    return data_.empty();
  }

private:
  mutable boost::mutex mutex_; /**< mutex protecting access */
  boost::condition_variable cond_; /**< condition checking that we have data ready */
  std::queue<T> data_; /**< data storage */
};

} /* namespace threadsafe */


/**
 * @class ThreadPool
 * @brief simple pool of threads
 */
class ThreadPool {
public:
  /**
   * @brief default constructor
   * sets number of threads to CPU cores * 2
   */
  ThreadPool();
  /**
   * @brief constructor
   * @param nb number of threads
   */
  ThreadPool(int nb);
  /**
   * @brief destructor
   */
  ~ThreadPool();

  /**
   * \brief add a function to a task
   * \param f function to call
   */
  template<typename Callable>
  void
  submit(Callable f) {
    tasks_.push(f);
  }


private:
  /**
   * @brief common initialization to all constructors
   */
  void
  setup();

  /**
   * @brief thread unit body
   */
  void
  WorkerThread();

  /* Note: boost::threads are not copyable so we can't store them in a
     standard container so we use boost::thread_group instead to manage
     our actual threads. */
  boost::thread_group workers_;/**< worker threads */
  threadsafe::queue<Task> tasks_; /**< scheduled tasks */
  int nb_; /**< number of allocated threads */
  volatile bool finished_; /**< is our pool running or not ? */
};




#endif /* _UTILS_HPP_ */
