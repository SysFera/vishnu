/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#include "Server.hpp"

#include <algorithm>
#include <vector>
#include <string>
#include <sstream>
#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/algorithm/string/regex.hpp>
#include <boost/algorithm/string/classification.hpp>
#include <boost/lexical_cast.hpp>

// typedef for readability and less typing
typedef std::vector<std::string> Services;


Server::Server(const std::string& name, const std::vector<std::string> &serv,
               const std::string& uri) :
    mname(name), mservices(serv), muri(uri) {
}

Server::~Server(){
}


int
Server::add(const std::string& service) {
  Services::iterator it =
    std::find(mservices.begin(), mservices.end(), service);

  if (it == mservices.end()) {
    mservices.push_back(service);
  }

  return 0;
}

int
Server::remove(const std::string& service) {
  // using erase/remove idiom
  Services::iterator it =
    std::remove(mservices.begin(), mservices.end(), service);

  mservices.erase(it, mservices.end());

  return 0;
}

bool
Server::hasService(const std::string& service) const {
  Services::const_iterator it  =
    std::find(mservices.begin(), mservices.end(), service);

  return (it != mservices.end());
}

std::string
Server::getName() const {
  return mname;
}


std::string
Server::getURI() const {
  return muri;
}

Services&
Server::getServices() {
  return mservices;
}


std::string
Server::toString() {
  std::stringstream res;
  unsigned int i;
  res << mname << "$$$"
      << muri << "$$$";
  for (i = 0 ; i < mservices.size() - 1 ; ++i){
    res << mservices.at(i) << "$$$";
  }
  res << mservices.at(mservices.size()-1) << "$$$";
  return res.str();
}

boost::shared_ptr<Server>
Server::fromString(const std::string& prof) {
  using boost::algorithm::split_regex;

  boost::shared_ptr<Server> res;
  std::vector<std::string> vecString;
  split_regex(vecString, prof, boost::regex("\\${3}"));
  std::string name;
  std::string uri;
  Services services;

  if (!vecString.empty()) {
    Services::iterator it = vecString.begin();
    name = *(it++);
    uri = *(it++);

    // we only copy non-empty strings to avoid deserialization errors
    std::remove_copy_if(it, vecString.end(),
                        std::back_inserter(services),
                        boost::bind(&std::string::empty, _1));

    res = boost::make_shared<Server>(name, services, uri);
  }
  return res;
}
