/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file CommServer.hpp
 * This file defines some utilitaries functions that use both the communication layer, the database layer, the core layer
 * \author Kevin Coulomb (kevin.coulomb@sysfera.com)
 */

#ifndef __COMMSERVER__HH__
#define __COMMSERVER__HH__

#include <boost/shared_ptr.hpp>
#include "ExecConfiguration.hpp"
#include "SeD.hpp"
#include "sslhelpers.hpp"

/**
 * \brief Function to unregister a server (from the annuary and database)
 * \param type the type of the server
 * \param config the configuration file
 * \return 0 currently
 */
int
unregisterSeD(const std::string& type, const ExecConfiguration& config);

/**
 * \brief Function to validate an URI
 * \throws a VishnuException if contains the '*'
 * \param uri the uri to check
 */
void
validateUri(const std::string & uri);

/**
 * \brief Register a server (in both the annuary and database)
 * \param type the type of the server
 * \param config the configuration file
 * \param services the list of the offered services
 * \return 0 on SUCCESS
 */
int
registerSeD(const std::string& type, const ExecConfiguration& config,
            std::vector<std::string>& services);

/**
 * \brief initSeD registers services and starts the SeD
 * \param type the type of the SeD (fmssed, imssed, tmssed, umssed)
 * \param config the SeD configuration
 * \param uri SeD URI
 * \param server the SeD
 */
void
initSeD(const std::string& type, const ExecConfiguration& config,
        const std::string& uri, boost::shared_ptr<SeD> server);



#endif  // __COMMSERVER__HH__
