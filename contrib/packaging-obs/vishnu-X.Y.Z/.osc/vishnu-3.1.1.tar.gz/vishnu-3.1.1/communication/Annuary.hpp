/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file Annuary.hpp
 * \brief This file defines the Annuary used to keep the servers
 * \author Kevin Coulomb (kevin.coulomb@sysfera.com)
 */
#ifndef __ANNUARY__H__
#define __ANNUARY__H__

#include "Server.hpp"
#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/thread/recursive_mutex.hpp>


/**
 * \brief This class represents the annuary to store the services
 * \class Annuary
 */
class Annuary {
public:
  /**
   * \brief Default constructor
   */
  Annuary() {}
  /**
   * \brief Constructor
   * \param serv
   */
  Annuary(const std::vector<boost::shared_ptr<Server> >& serv);
  /**
   * \brief destructor
   */
  ~Annuary() {}

  /**
   * \brief Add a server in the annuary
   * \param name The name of the server (e.g. UMS, TMS, dispatcher)
   * \param uri The uri the server is running
   * \param services The services offered by the server
   * \return 0 on success, an error code otherwise
   */
  int
  add(const std::string& name, const std::string& uri, const std::vector<std::string>& services);

  /**
   * \brief Remove the server called name listening on port at address of the annuary
   * \param name The name of the server (e.g. UMS, TMS, dispatcher)
   * \param uri The uri of the annuary
   * \return 0 on success, an error code otherwise
   */
  int
  remove(const std::string& name, const std::string& uri);

  /**
   * \brief Return all the servers offering the service called service
   * \param service The name of the desired service
   * \return A vector containing all the servers offering service
   */
  std::vector<boost::shared_ptr<Server> >
  get(const std::string& service = "");

  //TODO: clean later
  /**
   * \brief Init the annuary from a file
   * \param file The file to init from
   */
  void
  initFromFile(const std::string& file);


  /**
   * \brief Initialize the annuary with the configuration of the given module
   * \param module The name of the module
   * \param cfgInfo list of the initialisation data
   */
  void
  setInitConfig(const std::string& module, std::vector<std::string>& cfgInfo);

  /**
   * \brief Prints the content of the annuary
   */
  void
  print();

private :
  /**
   * \brief Fill the services for a given server name. Function used to easily create services from given names
   * \param services OUT, the list of services for name
   * \param name The name of the server
   * \param mid The vishnu machine id
   */
  void
  fillServices(std::vector<std::string> & services, const std::string& name,
               const std::string& mid);

  /**
   * \brief The servers
   */
  std::vector<boost::shared_ptr<Server> > mservers;

  /**
   * \brief mutex to lock the annuary
   */
  mutable boost::recursive_mutex mmutex;
};

#endif // __ANNUARY__H__
