
int
PQstatus(PGconn* conn){
  return 0;
}

int
PQresultStatus(PGresult* res){
  return 0;
}

PGresult*
PQexec(PGconn* conn, char* req);

void
PQclear(PGresult* res);

char*
PQerrorMessage(PGconn* conn);

void
PQfinish(PGconn* conn);

int 
PQnfields(PGresult* res);

char*
PQfname(PGresult* res, int pos);

int
PQntuples(PGresult* res);

char*
PQgetvalue(PGresult* res, int i, int j);
