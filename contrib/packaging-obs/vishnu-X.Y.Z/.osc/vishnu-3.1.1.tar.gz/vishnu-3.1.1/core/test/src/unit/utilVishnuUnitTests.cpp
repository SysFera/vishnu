/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

#include <boost/test/unit_test.hpp>
#include <string>
#include <sstream>
#include <map>

#include "UserException.hpp"
#include "utilVishnu.hpp"

BOOST_AUTO_TEST_SUITE( utilVishnu_unit_tests )

BOOST_AUTO_TEST_CASE( test_convertToString_n )
{

  std::string res = "12345";
  int  input_i = 12345;
  long input_l = 12345;

  BOOST_REQUIRE(vishnu::convertToString(input_l) == res);
  BOOST_REQUIRE(vishnu::convertToString(input_i) == res);
  BOOST_MESSAGE("Test convert to string OK");
}

BOOST_AUTO_TEST_CASE( test_convertToInt_n )
{

  std::string input = "12345";
  int res = 12345;

  BOOST_REQUIRE(vishnu::convertToInt(input) == res);
  BOOST_MESSAGE("Test convert to int OK");
}

BOOST_AUTO_TEST_CASE( test_convertToInt_b )
{

  std::string input = "pouet";

  BOOST_REQUIRE_NO_THROW(vishnu::convertToInt(input));
  BOOST_REQUIRE_EQUAL(vishnu::convertToInt(input), -1);
  BOOST_MESSAGE("Test convert to int OK");
}

BOOST_AUTO_TEST_CASE( test_convertToLong_n )
{

  std::string input = "12345";
  long res = 12345;

  BOOST_REQUIRE(vishnu::convertToLong(input) == res);
  BOOST_MESSAGE("Test convert to long OK");
}

BOOST_AUTO_TEST_CASE( test_convertToLong_b )
{

  std::string input = "pouet";

  BOOST_REQUIRE_NO_THROW(vishnu::convertToLong(input));
  BOOST_REQUIRE_EQUAL(vishnu::convertToLong(input), -1);
  BOOST_MESSAGE("Test convert to long OK");
}

BOOST_AUTO_TEST_CASE( test_convertToTimeType_n )
{

  std::string input_1 = "0000-00-00";
  std::string input_2 = "";
  long long res1 = 0;
  long long res2 = 0;

  BOOST_REQUIRE_EQUAL(vishnu::convertToTimeType(input_1), res1);
  BOOST_REQUIRE_EQUAL(vishnu::convertToTimeType(input_2), res2);
  BOOST_MESSAGE("Test convert to time type OK");
}

BOOST_AUTO_TEST_CASE( test_convertToTimeType_b )
{

  std::string input_3 = "0000-01-10";
  std::string input_4 = "2000-00-10";
  std::string input_5 = "2000-10-00";

  BOOST_REQUIRE_THROW(vishnu::convertToTimeType(input_3), UserException);
  BOOST_REQUIRE_THROW(vishnu::convertToTimeType(input_4), UserException);
  BOOST_REQUIRE_THROW(vishnu::convertToTimeType(input_5), UserException);
  BOOST_MESSAGE("Test convert to time type OK");
}

BOOST_AUTO_TEST_CASE( test_cryptPwd_n )
{

  std::string user = "root";
  std::string pwd  = "vishnu_user";
  std::string res = "8vU7h/n6KOW8reLF1Lt2/5gzjZ.HvGK3A9doVMbmPtaYKkkCoWrMKiPa7s.fEigSTS5gQmX5F8BlW2XotCeHa0";

  BOOST_REQUIRE(vishnu::cryptPassword(user, pwd) == res);
  BOOST_REQUIRE(vishnu::cryptPassword(user, pwd, true) == res);
  BOOST_REQUIRE(vishnu::cryptPassword(user, pwd, false) == pwd);
  BOOST_MESSAGE("Test cryptPwd OK");
}


BOOST_AUTO_TEST_CASE( test_isNumerical_n )
{
  std::string input_1 = "12345";
  std::string input_2 = "lapin";
  std::string input_3 = "james0";
  std::string input_4 = "";

  BOOST_REQUIRE(vishnu::isNumericalValue(input_1));
  BOOST_REQUIRE_THROW(vishnu::isNumericalValue(input_2), UserException);
  BOOST_REQUIRE_THROW(vishnu::isNumericalValue(input_3), UserException);
  BOOST_REQUIRE_THROW(vishnu::isNumericalValue(input_4), UserException);
  BOOST_MESSAGE("Test isNumerical OK");
}

BOOST_AUTO_TEST_CASE( test_checkMetricHistVal_n )
{
  int input_1 = 1;
  int input_2 = -2;
  int input_3 = 8;

  vishnu::checkMetricHistoryValue(input_1);
  BOOST_REQUIRE_THROW(vishnu::checkMetricHistoryValue(input_2), UserException);
  BOOST_REQUIRE_THROW(vishnu::checkMetricHistoryValue(input_3), UserException);
  BOOST_MESSAGE("Test check metric history value OK");
}

BOOST_AUTO_TEST_CASE( test_remotePath_n )
{
  std::string input_1 = "host:/path";
  std::string input_2 = "/345-4";
  std::string input_3 = "/lapin/tmp";

  vishnu::checkRemotePath(input_1);
  BOOST_REQUIRE_THROW(vishnu::checkRemotePath(input_2), VishnuException);
  BOOST_REQUIRE_THROW(vishnu::checkRemotePath(input_3), VishnuException);
  BOOST_MESSAGE("Test check remote path OK");
}


BOOST_AUTO_TEST_CASE( test_emptyString_n )
{
  std::string input_1 = "";
  std::string input_2 = " ";
  std::string input_3 = "blabla";

  BOOST_REQUIRE_THROW(vishnu::checkEmptyString(input_1, "fail"), UserException);
  vishnu::checkEmptyString(input_2, "ok");
  vishnu::checkEmptyString(input_3, "ok");
  BOOST_MESSAGE("Test check empty string OK");
}

BOOST_AUTO_TEST_CASE( test_isNotIP_nv4 )
{
  // IPv4
  BOOST_REQUIRE(!vishnu::isNotIP("127.0.0.1"));
  BOOST_REQUIRE(!vishnu::isNotIP("192.168.0.12"));
  BOOST_REQUIRE(!vishnu::isNotIP("1.2.3.4"));
}

BOOST_AUTO_TEST_CASE( test_isNotIP_nv6 )
{
  // IPv6
  BOOST_REQUIRE(!vishnu::isNotIP("fe80::fa1e:dfff:feec:2b2d"));
  BOOST_REQUIRE(!vishnu::isNotIP("fe80::200:ff:fe00:0"));
  BOOST_REQUIRE(!vishnu::isNotIP("fe80::224:e8ff:fe3c:f559"));
}

BOOST_AUTO_TEST_CASE( test_isNotIP_b )
{
  // IPv6
  BOOST_REQUIRE(vishnu::isNotIP("localhost"));
  BOOST_REQUIRE(vishnu::isNotIP("toto"));
  BOOST_REQUIRE(vishnu::isNotIP("127.0.1.1.1"));
  BOOST_REQUIRE(vishnu::isNotIP("127.0.a.b"));
}


BOOST_AUTO_TEST_SUITE_END()
