/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file MockDatabase.cpp
 * \brief This file implements the SQL database.
 * \author Kevin Coulomb (kevin.coulomb@sysfera.com)
 * \date 15/12/10
 */
#include "MockDatabase.hpp"

int
MockDatabase::process(std::string request, int transacId){
  return SUCCESS;
}
/**
 * \brief To make a connection to the database
 * \fn int connect()
 * \return raises an exception on error
 */
int
MockDatabase::connect(){
  return SUCCESS;
}
/**
 * \fn MockDatabase(DbConfiguration dbConfig)
 * \brief Constructor, raises an exception on error
 */
MockDatabase::MockDatabase(DbConfiguration dbConfig)
: Database() {
}

/**
 * \fn ~Database()
 * \brief Destructor, raises an exception on error
 */
MockDatabase::~MockDatabase(){
}
/**
 * \brief To disconnect from the database
 * \fn disconnect()
 * \return 0 on success, an error code otherwise
 */
int
MockDatabase::disconnect(){
  return SUCCESS;
}


/**
 * \brief To get the result of the latest request (if any result)
 * \param transacId the id of the transaction if one is used
 * \return The result of the latest request
 */
DatabaseResult*
MockDatabase::getResult(std::string request, int transacId) {
  std::vector<std::vector<std::string> > result;
  std::vector<std::string> param;
  return new DatabaseResult(result, param);
}

int
MockDatabase::startTransaction() {
  return 1;
}

void
MockDatabase::endTransaction(int transactionID) {
}

void
MockDatabase::cancelTransaction(int transactionID) {
}

void
MockDatabase::flush(int transactionID){
}

int
MockDatabase::generateId(std::string table, std::string fields, std::string val, int tid, std::string primary) {
  return 1;
}
