/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/


#ifndef _CONSTANTS_HPP_
#define _CONSTANTS_HPP_

#include <string>
#include <map>

namespace vishnu {
  /**
 * \brief Define a constant type
 */
  typedef enum {
    NONE_PARAMETER,
    BOOL_PARAMETER,
    INT_PARAMETER,
    ULONG_PARAMETER,
    STRING_PARAMETER,
    URI_PARAMETER
  } c_type_t ;

  /**
 * \brief Define a parameter type
 */

  typedef enum {
    VISHNUID=0,
    DBTYPE,
    DBHOST,
    DBPORT,
    DBNAME,
    DBUSERNAME,
    DBPASSWORD,
    SENDMAILSCRIPT,
    BATCHTYPE,
    BATCHVERSION,
    MACHINEID,
    TIMEOUT,
    REMOTEBINDIR,
    INTERVALMONITOR,
    DBPOOLSIZE,
    AUTHENTYPE,
    DEFAULTBATCHCONFIGFILE,
    URISUPERVISOR,
    DISP_URIADDR,
    DISP_URISUBS,
    DISP_NBTHREAD,
    FMS_URIADDR,
    IMS_URIADDR,
    TMS_URIADDR,
    UMS_URIADDR,
    CLOUDENDPOINT,
    DEBUG_LEVEL,
    DB_USE_SSL,
    DB_SSL_CA_FILE,
    USE_SSL,
    SERVER_PUBLIC_KEY,
    SERVER_PRIVATE_KEY,
    SERVER_SSL_CERTICATE,
    SSL_CA
  } param_type_t;

  /**
 * \brief For cloud
 */
  typedef enum {
    CLOUD_ENDPOINT,
    CLOUD_USER,
    CLOUD_USER_PASSWORD,
    CLOUD_TENANT,
    CLOUD_VM_IMAGE,
    CLOUD_VM_USER,
    CLOUD_VM_USER_KEY,
    CLOUD_DEFAULT_FLAVOR,
    CLOUD_NFS_SERVER,
    CLOUD_NFS_MOUNT_POINT
  } cloud_env_vars_t;

  /**
 * \brief States of jobs
 */
  typedef enum {
    STATE_UNDEFINED=0,
    STATE_SUBMITTED=1,
    STATE_QUEUED=2,
    STATE_WAITING=3,
    STATE_RUNNING=4,
    STATE_COMPLETED=5,
    STATE_CANCELLED=6,
    STATE_DOWNLOADED=7,
    STATE_FAILED=8
  } job_status_t;

  /**
   * \brief States of jobs
   */
  typedef enum {
    STATUS_UNDEFINED=-1,
    STATUS_LOCKED=0,
    STATUS_ACTIVE=1,
    STATUS_DELETED=2
  } component_status_t;

  /**
 * \brief A convenient data type to store a parameter
 */
  struct param_t {
    /**
   * \brief key to retrieve the parameter
   */
    param_type_t key;
    /**
   * \brief the value of the parameter
   */
    const std::string value;
    /**
   * \brief the type of the parameter
   */
    c_type_t type;
  };

  /**
 * \brief An array to store all parameters
 */
  extern param_t params[];  //%RELAX<MISRA_3_1_3> Because this table is defined in constants.cpp
  extern std::map<cloud_env_vars_t, std::string> CLOUD_ENV_VARS;
}

#endif /* _CONSTANTS_HPP_ */
