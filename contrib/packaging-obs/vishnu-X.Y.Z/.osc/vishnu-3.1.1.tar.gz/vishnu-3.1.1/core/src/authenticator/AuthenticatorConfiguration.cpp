/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file AuthenticatorConfiguration.cpp
 * \brief This file contains the definitions of the AuthenticatorConfiguration class
 * \author Eugène PAMBA CAPO-CHICHI
 * \date 3 Janvier 2012
*/

#include "AuthenticatorConfiguration.hpp"
#include <algorithm>
#include <iostream>

using namespace std;

/**
 * \brief Constructor
 * \param execConfig  the configuration of the program
 */
AuthenticatorConfiguration::AuthenticatorConfiguration(const ExecConfiguration& execConfig) :
mexecConfig(execConfig), mauthType(UMS)
{
}

/**
 * \brief Check that the configuration is correct
 */
void AuthenticatorConfiguration::check() throw (UserException)
{
  string authenTypeStr;
  if (!mexecConfig.getConfigValue(vishnu::AUTHENTYPE, authenTypeStr)) {
    std::cerr << "[INFO] The default authentication mode has been selected\n";
    authenTypeStr = "UMS";
  }

  std::transform(authenTypeStr.begin(), authenTypeStr.end(), authenTypeStr.begin(), ::tolower);
  if (authenTypeStr == "ums") {
    mauthType = AuthenticatorConfiguration::UMS;
  } else if (authenTypeStr == "ldap") {
    mauthType = AuthenticatorConfiguration::LDAP;
  } else if (authenTypeStr == "umsldap") {
    mauthType = AuthenticatorConfiguration::UMSLDAP;
  } else if (authenTypeStr == "ldapums") {
    mauthType = AuthenticatorConfiguration::LDAPUMS;
  } else {
    throw UserException(ERRCODE_INVALID_PARAM,
    "Invalid authentication mode. Supported mode are: 'UMS', 'LDAP', 'UMSLDAP' or 'LDAPUMS'");
  }
}
