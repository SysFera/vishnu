/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file ExecConfiguration.cpp
 */

#include "ExecConfiguration.hpp"

#include <boost/algorithm/string/classification.hpp>  // for is_any_of
#include <boost/algorithm/string/detail/classification.hpp>
#include <boost/algorithm/string/split.hpp>  // for split
#include <boost/iterator/iterator_facade.hpp>  // for operator!=
#include <boost/range/iterator_range_core.hpp>  // for operator==

#include "FileParser.hpp"               // for FileParser
#include "constants.hpp"                // for param_t, param_type_t, etc

using namespace std;

const std::string simple_cast_traits<std::string>::zero_value = "";


/**
 * \brief Constructor
 */
ExecConfiguration::ExecConfiguration()
{
}


/**
 * \brief Initialize from a file
 * \param filePath  full path of the configuration filePath
 */
void ExecConfiguration::initFromFile(std::string filePath) throw (UserException, std::exception)
{
  FileParser fileParser;
  fileParser.parseFile(filePath);
  mconfig = fileParser.getConfiguration();
}


/**
 * \brief Get the value of a configuration parameter
 * \param[in]  param
 * \param[out] value result
 * \return param has been set or not
 */
template<>
bool
ExecConfiguration::getConfigValue(vishnu::param_type_t param, std::string& value) const
{
  const std::string& key = (vishnu::params)[param].value;
  ConfigMap::const_iterator it = mconfig.find(key);
  if (mconfig.end() == it) {
    return false;
  } else {
    value = it->second;
    return true;
  }
}

/**
 * \brief Get the values of a configuration parameter
 * \param[in]  param
 * \param[out] value the list of result
 * \return param has been set or not
 */
bool
ExecConfiguration::getConfigValues(vishnu::param_type_t param, std::vector<std::string>& values) const {
  const std::string& key = (vishnu::params)[param].value;
  ConfigMap::const_iterator it = mconfig.find(key);
  if (mconfig.end() == it) {
    return false;
  }
  boost::split(values, it->second, boost::is_any_of(";"));
  return true;
}

/**
 * \brief Get the values of a configuration parameter
 * \param[in]  key
 * \param[out] value the list of result
 * \return values has been set or not
 */

bool
ExecConfiguration::getConfigValues(std::string& key, std::vector<std::string>& values) const {
  ConfigMap::const_iterator it = mconfig.find(key);
  if (mconfig.end() == it) {
    return false;
  }
  boost::split(values, it->second, boost::is_any_of(";"));
  return true;
}


string
ExecConfiguration::scriptToString() const {
  string res;
  for (ConfigMap::const_iterator it = mconfig.begin();
       it != mconfig.end();
       ++it) {
    res += it->first;
    res += "=";
    res += it->second;
    res += "\n";
  }
  return res;
}
