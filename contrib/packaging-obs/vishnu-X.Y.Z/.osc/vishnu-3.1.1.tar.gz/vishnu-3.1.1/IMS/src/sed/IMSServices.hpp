/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file IMSServices.hpp
 * \brief This file lists the services provided by IMS servers.
 * \author Benjamin Depardon (benjamin.depardon@sysfera.com)
 * \date 21/02/2013
 */

#ifndef _IMSSERVICES_HPP_
#define _IMSSERVICES_HPP_

/**
 * \brief TMS services enumeration
 */
typedef enum {
  INT_EXPORTCOMMANDS,
  INT_GETMETRICCURENTVALUE,
  INT_GETMETRICHISTORY,
  INT_GETPROCESSES,
  INT_SETSYSTEMINFO,
  INT_SETSYSTEMTHRESHOLD,
  INT_GETSYSTEMTHRESHOLD,
  INT_LOADSHED,
  INT_SETUPDATEFREQUENCY,
  INT_GETUPDATEFREQUENCY,
  INT_RESTART,
  INT_STOP,
  INT_GETSYSTEMINFO,
  NB_SRV_IMS  // MUST always be the last
} ims_service_t;

static const char* SERVICES_IMS[NB_SRV_IMS] = {
  "int_exportCommands", // 0
  "int_getMetricCurentValue", // 1
  "int_getMetricHistory", // 2
  "int_getProcesses", // 3
  "int_setSystemInfo", // 4
  "int_setSystemThreshold", // 5
  "int_getSystemThreshold", // 6
  "int_loadShed", // 11
  "int_setUpdateFrequency", // 12
  "int_getUpdateFrequency", // 13
  "int_restart", // 14
  "int_stop", // 15
  "int_getSystemInfo" // 16
};

static const bool MACHINE_SPECIC_SERVICES_IMS[NB_SRV_IMS] = {
  false,  // 0
  true,   // 1
  false,  // 2
  false,  // 3
  false,  // 4
  false,  // 5
  false,  // 6
  true,   // 11
  false,  // 12
  false,  // 13
  true,   // 14
  true,   // 15
  false  // 16
};


#endif  // _IMSSERVICES_HPP_
