/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file stop.cpp
 * This file defines the VISHNU command to stop a vishnu process
 * \author Eugène PAMBA CAPO-CHICHI(eugene.capochichi@sysfera.com)
 */


#include "CLICmd.hpp"
#include "utilVishnu.hpp"
#include "cliError.hpp"
#include "cliUtil.hpp"
#include "api_ums.hpp"
#include "api_ims.hpp"
#include "sessionUtils.hpp"
#include <boost/bind.hpp>

#include "GenericCli.hpp"

using namespace std;
using namespace vishnu;

struct LoadShedFunc {

 IMS_Data::LoadShedType mloadShedType;
 std::string mmachineId;
// IMS_Data::SupervisorOp mop;

  LoadShedFunc(const IMS_Data::LoadShedType& loadShedType, const std::string& machineId):
    mloadShedType(loadShedType), mmachineId(machineId)
  {};

  int operator()(std::string sessionKey) {
    return loadShed(sessionKey, mmachineId, mloadShedType);
  }
};


int main (int argc, char* argv[]){

  /******* Parsed value containers ****************/
  string configFile;
  string machineId;

   /********** EMF data ************/
  IMS_Data::LoadShedType loadShedType;
//  IMS_Data::SupervisorOp op;

  /**************** Describe options *************/
//  boost::function1<void,string> fsc(boost::bind(&IMS_Data::SupervisorOp::setURI,boost::ref(op),_1));
  boost::shared_ptr<Options> opt(new Options(argv[0]));

  // Environement option
  opt->add("configFile,c",
           "VISHNU configuration file",
           ENV,
           configFile);

  opt->add( "machineId,i",
            "represents the id of the machine",
            HIDDEN,
            machineId,1);

  opt->setPosition("machineId",1);

  opt->add( "loadShedType,l",
            " represents the type of the load shedding. The different values are:\n"
            "1 for HARD\n"
            "2 for SOFT",
            HIDDEN,
            loadShedType,1);

  opt->setPosition("loadShedType",1);

//  opt->add("script,s",
//	   "The supervisor script",
//	   CONFIG,
//	   fsc);

  bool isEmpty;
  //To process list options
  GenericCli().processListOpt(opt, isEmpty, argc, argv, "loadShedType values: 1 for HARD and 2 for SOFT");

  //call of the api function
  LoadShedFunc loadShedFunc(loadShedType, machineId);
  return GenericCli().run(loadShedFunc, configFile, argc, argv);
}
