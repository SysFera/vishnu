/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * IMS_fixtures.hpp
 *
 * Author : E. PAMBA CAPO-CHICHI
 */

#ifndef _IMS_FIXTURES_HPP_
#define _IMS_FIXTURES_HPP_

#include "TMS_fixtures.hpp"

#include <string>
#include <map>
#include <boost/test/unit_test.hpp>
#include "api_tms.hpp"
#include "api_ums.hpp"
#include "api_ims.hpp"
#include "FileParser.hpp"



class IMSSeDFixture : public TMSSeDFixture {

public:

  std::string m_test_ims_admin_vishnu_login;
  std::string m_test_ims_admin_vishnu_pwd;
  std::string m_test_ims_user_vishnu_login;
  std::string m_test_ims_user_vishnu_pwd;


  IMSSeDFixture():mac(2){

    BOOST_TEST_MESSAGE( "== Test setup [BEGIN]: Initializing client ==" );
    // Name of the test executable
    mav[0]= (char*)"./ims_automTest";
    // Client configuration file
    std::string dietClientConfigPath = getenv("VISHNU_CLIENT_TEST_CONFIG_FILE");
    mav[1]= (char*) dietClientConfigPath.c_str();

    if (vishnu::vishnuInitialize(mav[1], mac, mav)) {
      BOOST_TEST_MESSAGE( "Error in VishnuInitialize..." );
    }
    BOOST_TEST_MESSAGE( "== Test setup [END]: Initializing client ==" );

    BOOST_TEST_MESSAGE( "== Test setup [BEGIN]: LOADING SETUP ==" );
    std::string vishnuTestSetupPath = getenv("VISHNU_TEST_SETUP_FILE");
    FileParser fileparser(vishnuTestSetupPath.c_str());
    std::map<std::string, std::string> setupConfig = fileparser.getConfiguration();

    m_test_ims_admin_vishnu_login = setupConfig.find("TEST_ADMIN_VISHNU_LOGIN")->second;
    m_test_ims_admin_vishnu_pwd = setupConfig.find("TEST_ADMIN_VISHNU_PWD")->second;
    m_test_ims_user_vishnu_login = setupConfig.find("TEST_USER_VISHNU_LOGIN")->second;
    m_test_ims_user_vishnu_pwd = setupConfig.find("TEST_USER_VISHNU_PWD")->second;
    m_test_ums_user_vishnu_machineid = setupConfig.find("TEST_VISHNU_MACHINEID1")->second;


    BOOST_TEST_MESSAGE( "== Test setup [END]: LOADING SETUP ==" );
  }

  ~IMSSeDFixture() {
    BOOST_TEST_MESSAGE( "== Test teardown [BEGIN]: IMSSeDFixture ==" );
    BOOST_TEST_MESSAGE( "== Test teardown [END]: IMSSeDFixture ==" );
  }

  int mac;
  char* mav[2];
};


#endif  // _FMS_FIXTURES_HPP_
