/* This file is a part of VISHNU.

* Copyright SysFera SA (2011) 

* contact@sysfera.com

* This software is a computer program whose purpose is to provide 
* access to distributed computing resources.
*
* This software is governed by the CeCILL  license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 

* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/**
 * \file ims_automTest
 * \brief Contains IMS API test implementation
 * References: VISHNU_D5_1b_IMS-PlanTests
 */
/*********************************************************
#####Tests prerequisites:#######
- All ums and tms prerequisites must be considered
- The Cmake variable TEST_LOCAL_HOSTNAME, which is the name of the
local machine on which the tests will be launched,
must be defined.

- The Cmake variable TEST_ROOT_LOGIN which is the name of the user unix
account of local machine must be defined

*********************************************************/

//UMS forward Headers
#include "UMS_Data_forward.hpp"
//IMS forward Headers
#include "IMS_Data_forward.hpp"
#include "IMS_fixtures.hpp"
#include "vishnuTestUtils.hpp"
#include "utilVishnu.hpp"


#include "TMS_Data.hpp"
using namespace TMS_Data;

// C++ Headers
#include <iostream>
#include <sstream>
#include <cmath>

// Boost Headers
#include <boost/thread.hpp>
#include <boost/filesystem.hpp>
#include <boost/filesystem/fstream.hpp>

// namespaces declaration and  aliases
using namespace std;
using namespace UMS_Data;
using namespace IMS_Data;
using namespace vishnu;
namespace bpt= boost::posix_time;
namespace bfs= boost::filesystem;


static const string badMachineId="unknown_name";
static const string sshCmd =" ssh -o PasswordAuthentication=no ";

BOOST_FIXTURE_TEST_SUITE(export_command, IMSSeDFixture)

#ifdef COMPILE_TMS
//Test category 1
//I3-B: export and replay commands
BOOST_AUTO_TEST_CASE(export_command_normal_call)
{

  BOOST_TEST_MESSAGE("Use case I3 - B: Export and replay commands normal call");
  VishnuConnection vc(m_test_ims_admin_vishnu_login, m_test_ims_admin_vishnu_pwd);
  // get the session key and the machine identifier
  string sessionKey=vc.getSessionKey();
  // Command history
  UMS_Data::ListCommands listCmd;
  UMS_Data::ListCmdOptions listCmdOpt ;
  // List Sessions
  ListSessions listSess;
  ListSessionOptions listSessionsOpt;
  //Options for export
  IMS_Data::ExportOp exportOp;
  //1 for Shell export
  exportOp.setExportType(1);
  string filename = "tmpTest.txt";
  string filePath;
  string fileContent;
  string tmp;
  //Session in which the commands will be exported
  Session sess ;
  ConnectOptions connectOpt;
  //Set close policy : on disconnect
  connectOpt.setClosePolicy(2);
  //ListJobs
  ListJobs lsJobs;
  ListJobsOptions lsOptions;
  //To list metric history
  IMS_Data::ListMetric list;
  IMS_Data::MetricHistOp op;
  //Set FREEMOMORY metric
  op.setType(5);

  try {
    //To open a session to launch commands
    BOOST_CHECK_EQUAL(connect(m_test_ims_admin_vishnu_login, m_test_ims_admin_vishnu_pwd, sess, connectOpt), 0);
    //To list sessions
    BOOST_CHECK_EQUAL(listSessions(sess.getSessionKey(), listSess, listSessionsOpt), 0);
    //To list jobs
    BOOST_CHECK_EQUAL(listJobs(sessionKey, m_test_ums_user_vishnu_machineid, lsJobs, lsOptions), 0);
    //To list metric history
    BOOST_CHECK_EQUAL(getMetricHistory(sess.getSessionKey(), m_test_ums_user_vishnu_machineid, list, op),0  );
    listCmdOpt.setSessionId(sess.getSessionId());
    //To list the commands
    BOOST_CHECK_EQUAL(vishnu::listHistoryCmd(sess.getSessionKey(), listCmd, listCmdOpt), 0);
    BOOST_REQUIRE(listCmd.getCommands().size() != 0);
    //To close session
    BOOST_CHECK_EQUAL(close (sess.getSessionKey()), 0);
    //To create a locate file for the test
    std::ofstream file(filename.c_str());
    filePath = boost::filesystem::current_path().string() +"/"+ filename;
    //To create the file in which the command will be saved
    if (!file.is_open()) {
      throw UserException(ERRCODE_INVALID_PARAM, "Error opening file: " + filename);
    }
    BOOST_CHECK_EQUAL(exportCommands(sessionKey, sess.getSessionId(), filePath, exportOp), 0);
    fileContent = vishnu::get_file_content(filePath.c_str());
    //To check if the file is not empty
    BOOST_REQUIRE(fileContent.size() != 0);
    //To check the mapping between export and listHistoryCmd
    for(unsigned int i = 0; i < listCmd.getCommands().size(); i++) {
      tmp = listCmd.getCommands().get(i)->getCmdDescription();
      //To check if the file contains the current command
      BOOST_REQUIRE(fileContent.find(tmp)!=string::npos);
    }
    //To remove the temporary file
    vishnu::deleteFile(filePath.c_str());
  }
  catch (VishnuException& e) {
    BOOST_MESSAGE("FAILED\n");
    BOOST_MESSAGE(e.what());
    BOOST_CHECK(false);
    try {
      //To remove the temporary file
      vishnu::deleteFile(filePath.c_str());
    } catch (exception& exp) {
      BOOST_MESSAGE(exp.what());
    }
  }
}

#endif // COMPILE_TMS

//I3-E1: export and replay commands with bad old session Id
BOOST_AUTO_TEST_CASE(export_command_bad_old_session_Id_call) {

  BOOST_TEST_MESSAGE("Use case I3 - E1: Export and replay commands with bad old session Id call");
  VishnuConnection vc(m_test_ims_admin_vishnu_login, m_test_ims_admin_vishnu_pwd);
  // get the session key and the machine identifier
  string sessionKey=vc.getSessionKey();
  //Options for export
  IMS_Data::ExportOp exportOp;
  //1 for Shell export
  exportOp.setExportType(1);
  string filename = "tmpTest.txt";
  string filePath;
  string badSessionId = "badSessionId";
  //To create a locate file for the test
  std::ofstream file(filename.c_str());
  filePath = boost::filesystem::current_path().string() +"/"+ filename;
  //To create the file in which the command will be saved
  if (!file.is_open()) {
    throw UserException(ERRCODE_INVALID_PARAM, "Error opening file: " + filename);
  }
  BOOST_CHECK_THROW(exportCommands(sessionKey, badSessionId, filePath, exportOp), VishnuException);
  //To remove the temporary file
  vishnu::deleteFile(filePath.c_str());
}

//I3-E2: export and replay commands with bad file path
BOOST_AUTO_TEST_CASE(export_command_bad_file_path_call) {

  BOOST_TEST_MESSAGE("Use case I3 - E2: Export and replay commands with bad file path");
  VishnuConnection vc(m_test_ims_admin_vishnu_login, m_test_ims_admin_vishnu_pwd);
  // get the session key and the machine identifier
  string sessionKey=vc.getSessionKey();
  //Options for export
  IMS_Data::ExportOp exportOp;
  //1 for Shell export
  exportOp.setExportType(1);
  string filePath = "/home/Paco/DeLaStagna";
  //Session
  Session sess ;
  //Connection options
  ConnectOptions connectOpt;
  //Set close policy : on disconnect
  connectOpt.setClosePolicy(2);
  //To open a session
  BOOST_CHECK_EQUAL(connect(m_test_ims_admin_vishnu_login, m_test_ims_admin_vishnu_pwd, sess, connectOpt), 0);
  //To close session
  BOOST_CHECK_EQUAL(close (sess.getSessionKey()), 0);

  BOOST_CHECK_THROW(exportCommands(sessionKey, sess.getSessionId(), filePath, exportOp), VishnuException);

}

BOOST_AUTO_TEST_SUITE_END()
// THE END
